package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.example.data.db.AppDatabase
import com.example.data.preferences.PreferencesManager
import com.example.data.repository.TransferRepository

class DropifyApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var transferRepository: TransferRepository
        private set

    lateinit var preferencesManager: PreferencesManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

// Initialize Room Database & Repository
        database = AppDatabase.getDatabase(this)
        transferRepository = TransferRepository(database.transferDao())
        preferencesManager = PreferencesManager(this)

        // Create Notification Channel for File Transfers
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID_TRANSFERS,
                "File Transfers",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows real-time progress for active nearby file transfers"
                setShowBadge(false)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID_TRANSFERS = "dropify_transfers_channel"
        lateinit var instance: DropifyApp
            private set
    }
}
