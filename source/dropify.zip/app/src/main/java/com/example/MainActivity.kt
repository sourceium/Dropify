package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.model.FileItem
import com.example.data.model.TransferState
import com.example.ui.components.DrawerMenu
import com.example.ui.components.IncomingTransferDialog
import com.example.ui.components.PermissionHelper
import com.example.ui.components.TopBar
import com.example.ui.navigation.Screen
import com.example.ui.screens.DeviceDiscoveryScreen
import com.example.ui.screens.HistoryDetailScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileSetupScreen
import com.example.ui.screens.QrDisplayScreen
import com.example.ui.screens.QrScanScreen
import com.example.ui.screens.ReceiveWaitingScreen
import com.example.ui.screens.SendFilePickerScreen
import com.example.ui.screens.SendReviewScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.TransferCompleteScreen
import com.example.ui.screens.TransferProgressScreen
import com.example.ui.theme.DropifyTheme
import com.example.ui.theme.GlideShareTheme
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: MainViewModel = viewModel()
            val userPrefs by viewModel.userPreferences.collectAsStateWithLifecycle()

            DropifyTheme(themeSetting = userPrefs.themeSetting) {
                DropifyAppNav(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun DropifyAppNav(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val userPrefs by viewModel.userPreferences.collectAsStateWithLifecycle()
    val activeSession by viewModel.activeSession.collectAsStateWithLifecycle()
    val incomingRequest by viewModel.incomingRequest.collectAsStateWithLifecycle()
    val incomingFilesMetadata by viewModel.incomingFilesMetadata.collectAsStateWithLifecycle()
    val selectedFiles by viewModel.selectedFiles.collectAsStateWithLifecycle()
    val discoveredDevices by viewModel.discoveredDevices.collectAsStateWithLifecycle()
    val historyTransfers by viewModel.historyTransfers.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    // Permission launcher for nearby sharing
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (!allGranted) {
            scope.launch {
                snackbarHostState.showSnackbar("Nearby permissions are required to discover and transfer files.")
            }
        }
    }

    // Helper to query metadata from content URI
    fun queryFileItem(context: android.content.Context, uri: Uri): FileItem {
        var name = "file_${System.currentTimeMillis()}"
        var size = 0L
        val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) name = cursor.getString(nameIndex) ?: name
                    if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (_: Exception) {}

        return FileItem(uri = uri, name = name, size = size, mimeType = mime)
    }

    val context = androidx.compose.ui.platform.LocalContext.current

    // Modern Android Category file pickers
    val categoryDocPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            val items = uris.map { queryFileItem(context, it) }
            viewModel.addSelectedFiles(items)
            navController.navigate(Screen.SendReview.route)
        }
    }

    // React to status messages
    LaunchedEffect(statusMessage) {
        statusMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearStatusMessage()
        }
    }

    // Auto-navigate to transfer progress when session active
    LaunchedEffect(activeSession?.state) {
        when (activeSession?.state) {
            TransferState.TRANSFERRING, TransferState.ACCEPTED -> {
                if (navController.currentDestination?.route != Screen.TransferProgress.route) {
                    navController.navigate(Screen.TransferProgress.route)
                }
            }
            TransferState.COMPLETED -> {
                if (navController.currentDestination?.route != Screen.TransferComplete.route) {
                    navController.navigate(Screen.TransferComplete.route)
                }
            }
            else -> {}
        }
    }

    // Incoming transfer request dialog
    incomingRequest?.let { request ->
        IncomingTransferDialog(
            request = request,
            incomingFiles = incomingFilesMetadata,
            onAccept = {
                viewModel.acceptIncomingRequest()
            },
            onDecline = {
                viewModel.declineIncomingRequest()
            }
        )
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerMenu(
                deviceName = userPrefs.deviceName,
                avatarId = userPrefs.avatarId,
                onNavigateToHistory = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Screen.History.route)
                },
                onNavigateToSettings = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Screen.Settings.route)
                },
                onNavigateToAbout = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Screen.Settings.route)
                },
                onEditProfile = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Screen.ProfileEdit.route)
                }
            )
        }
    ) {
        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = {
                SnackbarHost(
                    hostState = snackbarHostState,
                    modifier = Modifier.navigationBarsPadding()
                )
            },
            modifier = Modifier.fillMaxSize()
        ) { _ ->
            NavHost(
                navController = navController,
                startDestination = Screen.Splash.route,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(Screen.Splash.route) {
                    SplashScreen(
                        isPreferencesLoaded = userPrefs.isLoaded,
                        isProfileConfigured = userPrefs.isProfileConfigured,
                        onNavigateNext = { configured ->
                            if (configured) {
                                navController.navigate(Screen.Home.route) {
                                    popUpTo(Screen.Splash.route) { inclusive = true }
                                }
                            } else {
                                navController.navigate(Screen.ProfileSetup.route) {
                                    popUpTo(Screen.Splash.route) { inclusive = true }
                                }
                            }
                        }
                    )
                }

                composable(Screen.ProfileSetup.route) {
                    ProfileSetupScreen(
                        initialDeviceName = userPrefs.deviceName,
                        initialAvatarId = userPrefs.avatarId,
                        isEditMode = false,
                        onBackClick = null,
                        onSaveProfile = { name, avatarId ->
                            viewModel.saveProfile(name, avatarId)
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.ProfileSetup.route) { inclusive = true }
                            }
                        }
                    )
                }

                composable(Screen.ProfileEdit.route) {
                    ProfileSetupScreen(
                        initialDeviceName = userPrefs.deviceName,
                        initialAvatarId = userPrefs.avatarId,
                        isEditMode = true,
                        onBackClick = {
                            navController.popBackStack()
                        },
                        onSaveProfile = { name, avatarId ->
                            viewModel.saveProfile(name, avatarId)
                            navController.popBackStack()
                        }
                    )
                }

                composable(Screen.Home.route) {
                    Scaffold(
                        contentWindowInsets = WindowInsets(0, 0, 0, 0),
                        topBar = {
                            TopBar(
                                avatarId = userPrefs.avatarId,
                                onMenuClick = {
                                    scope.launch { drawerState.open() }
                                },
                                onAvatarClick = {
                                    navController.navigate(Screen.ProfileEdit.route)
                                }
                            )
                        }
                    ) { homePadding ->
                        HomeScreen(
                            deviceName = userPrefs.deviceName,
                            avatarId = userPrefs.avatarId,
                            recentTransfers = historyTransfers.take(3),
                            onSendClick = {
                                val perms = PermissionHelper.getRequiredNearbyPermissions()
                                if (!PermissionHelper.hasPermissions(context, perms)) {
                                    permissionLauncher.launch(perms.toTypedArray())
                                }
                                navController.navigate(Screen.SendFilePicker.route)
                            },
                            onReceiveClick = {
                                val perms = PermissionHelper.getRequiredNearbyPermissions()
                                if (!PermissionHelper.hasPermissions(context, perms)) {
                                    permissionLauncher.launch(perms.toTypedArray())
                                }
                                navController.navigate(Screen.ReceiveWaiting.route)
                            },
                            onHistoryClick = {
                                navController.navigate(Screen.History.route)
                            },
                            onQuickCategoryClick = { mimeFilter ->
                                val perms = PermissionHelper.getRequiredNearbyPermissions()
                                if (!PermissionHelper.hasPermissions(context, perms)) {
                                    permissionLauncher.launch(perms.toTypedArray())
                                }
                                categoryDocPicker.launch(arrayOf(mimeFilter))
                            },
                            onScanQrClick = {
                                val perms = PermissionHelper.getRequiredNearbyPermissions()
                                if (!PermissionHelper.hasPermissions(context, perms)) {
                                    permissionLauncher.launch(perms.toTypedArray())
                                }
                                navController.navigate(Screen.QrScan.route)
                            },
                            onShowQrClick = {
                                navController.navigate(Screen.QrDisplay.route)
                            },
                            onProfileClick = {
                                navController.navigate(Screen.ProfileEdit.route)
                            },
                            onTransferClick = { transfer ->
                                navController.navigate(Screen.HistoryDetail.createRoute(transfer.id))
                            },
                            modifier = Modifier.padding(homePadding)
                        )
                    }
                }

                composable(Screen.SendFilePicker.route) {
                    SendFilePickerScreen(
                        selectedFiles = selectedFiles,
                        onFilesSelected = { newFiles ->
                            viewModel.addSelectedFiles(newFiles)
                        },
                        onNavigateToReview = {
                            navController.navigate(Screen.SendReview.route)
                        },
                        onBackClick = {
                            navController.popBackStack()
                        }
                    )
                }

                composable(Screen.SendReview.route) {
                    SendReviewScreen(
                        files = selectedFiles,
                        onRemoveFile = { file ->
                            viewModel.removeSelectedFile(file)
                        },
                        onAddMoreClick = {
                            navController.navigate(Screen.SendFilePicker.route)
                        },
                        onClearAll = {
                            viewModel.clearSelectedFiles()
                        },
                        onContinueToDiscovery = {
                            navController.navigate(Screen.DeviceDiscovery.route)
                        },
                        onBackClick = {
                            navController.popBackStack()
                        }
                    )
                }

                composable(Screen.DeviceDiscovery.route) {
                    DeviceDiscoveryScreen(
                        discoveredDevices = discoveredDevices,
                        onStartDiscovery = {
                            viewModel.startDiscovery()
                        },
                        onStopDiscovery = {
                            viewModel.stopDiscovery()
                        },
                        onDeviceSelected = { device ->
                            viewModel.connectToDevice(device)
                        },
                        onScanQrClick = {
                            navController.navigate(Screen.QrScan.route)
                        },
                        onBackClick = {
                            viewModel.stopDiscovery()
                            navController.popBackStack()
                        }
                    )
                }

                composable(Screen.ReceiveWaiting.route) {
                    ReceiveWaitingScreen(
                        deviceName = userPrefs.deviceName,
                        avatarId = userPrefs.avatarId,
                        onStartAdvertising = {
                            viewModel.startAdvertising()
                        },
                        onStopAdvertising = {
                            viewModel.stopAdvertising()
                        },
                        onShowQrClick = {
                            navController.navigate(Screen.QrDisplay.route)
                        },
                        onBackClick = {
                            viewModel.stopAdvertising()
                            navController.popBackStack()
                        }
                    )
                }

                composable(Screen.TransferProgress.route) {
                    val session = activeSession
                    if (session != null) {
                        TransferProgressScreen(
                            session = session,
                            localDeviceName = userPrefs.deviceName,
                            localAvatarId = userPrefs.avatarId,
                            onCancelTransfer = {
                                viewModel.cancelActiveTransfer()
                                navController.popBackStack(Screen.Home.route, inclusive = false)
                            }
                        )
                    } else {
                        LaunchedEffect(Unit) {
                            navController.popBackStack(Screen.Home.route, inclusive = false)
                        }
                    }
                }

                composable(Screen.TransferComplete.route) {
                    TransferCompleteScreen(
                        session = activeSession,
                        onDoneClick = {
                            viewModel.resetTransferSession()
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.Home.route) { inclusive = true }
                            }
                        }
                    )
                }

                composable(Screen.History.route) {
                    HistoryScreen(
                        transfers = historyTransfers,
                        onItemClick = { transfer ->
                            navController.navigate(Screen.HistoryDetail.createRoute(transfer.id))
                        },
                        onClearHistory = {
                            viewModel.clearHistory()
                        },
                        onBackClick = {
                            navController.popBackStack()
                        },
                        onDeleteTransfer = { id ->
                            viewModel.deleteTransfer(id)
                        }
                    )
                }

                composable(
                    route = Screen.HistoryDetail.route,
                    arguments = listOf(navArgument("id") { type = NavType.LongType })
                ) { backStackEntry ->
                    val id = backStackEntry.arguments?.getLong("id") ?: 0L
                    val transfer = historyTransfers.find { it.id == id }
                    HistoryDetailScreen(
                        transfer = transfer,
                        onBackClick = {
                            navController.popBackStack()
                        }
                    )
                }

                composable(Screen.Settings.route) {
                    SettingsScreen(
                        userPreferences = userPrefs,
                        onEditProfileClick = {
                            navController.navigate(Screen.ProfileEdit.route)
                        },
                        onThemeSelected = { theme ->
                            viewModel.setThemeSetting(theme)
                        },
                        onDeviceVisibilityToggle = { visible ->
                            viewModel.setDeviceVisibility(visible)
                        },
                        onClearHistoryClick = {
                            viewModel.clearHistory()
                        },
                        onBackClick = {
                            navController.popBackStack()
                        }
                    )
                }

                composable(Screen.QrDisplay.route) {
                    QrDisplayScreen(
                        deviceName = userPrefs.deviceName,
                        avatarId = userPrefs.avatarId,
                        generateQrPayload = {
                            viewModel.generateQrPairingData()
                        },
                        onBackClick = {
                            navController.popBackStack()
                        }
                    )
                }

                composable(Screen.QrScan.route) {
                    QrScanScreen(
                        onQrScanned = { qrResult ->
                            viewModel.handleQrScanResult(qrResult)
                            navController.popBackStack()
                        },
                        onBackClick = {
                            navController.popBackStack()
                        }
                    )
                }
            }
        }
    }
}
