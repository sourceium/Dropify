package com.example.data.db

import androidx.room.TypeConverter
import com.example.data.model.FileMetadata
import org.json.JSONArray
import org.json.JSONObject

class Converters {

    @TypeConverter
    fun fromFileMetadataList(list: List<FileMetadata>?): String {
        if (list.isNullOrEmpty()) return "[]"
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("name", item.name)
                put("size", item.size)
                put("mimeType", item.mimeType)
                put("uri", item.uri)
            }
            array.put(obj)
        }
        return array.toString()
    }

    @TypeConverter
    fun toFileMetadataList(json: String?): List<FileMetadata> {
        if (json.isNullOrBlank()) return emptyList()
        val result = mutableListOf<FileMetadata>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(
                    FileMetadata(
                        name = obj.optString("name", "Unknown"),
                        size = obj.optLong("size", 0L),
                        mimeType = obj.optString("mimeType", "application/octet-stream"),
                        uri = obj.optString("uri", "")
                    )
                )
            }
        } catch (_: Exception) {}
        return result
    }
}
