package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TransferDao {

    @Query("SELECT * FROM transfer_history ORDER BY timestamp DESC")
    fun getAllTransfers(): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfer_history WHERE direction = :direction ORDER BY timestamp DESC")
    fun getTransfersByDirection(direction: String): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfer_history WHERE status = :status ORDER BY timestamp DESC")
    fun getTransfersByStatus(status: String): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfer_history WHERE id = :id LIMIT 1")
    suspend fun getTransferById(id: Long): TransferEntity?

    @Query("SELECT * FROM transfer_history WHERE fileNames LIKE '%' || :query || '%' OR deviceName LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchTransfers(query: String): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfer_history ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentTransfers(limit: Int): Flow<List<TransferEntity>>

    @Query("SELECT COUNT(*) FROM transfer_history")
    fun getTransferCount(): Flow<Int>

    @Query("SELECT SUM(totalBytes) FROM transfer_history WHERE status = 'COMPLETED'")
    fun getTotalBytesTransferred(): Flow<Long?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransfer(transfer: TransferEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(transfers: List<TransferEntity>)

    @Query("DELETE FROM transfer_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM transfer_history")
    suspend fun clearAll()
}
