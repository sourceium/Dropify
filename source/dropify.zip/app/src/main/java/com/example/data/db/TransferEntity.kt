package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.FileMetadata
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "transfer_history")
data class TransferEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val direction: String, // "SENT" or "RECEIVED"
    val deviceName: String,
    val avatarId: Int = 0,
    val fileCount: Int,
    val totalBytes: Long,
    val status: String, // "COMPLETED", "FAILED", "CANCELLED"
    val speedBps: Long = 0L,
    val fileNames: String = "", // Comma-separated summary string
    val files: List<FileMetadata> = emptyList() // Detailed file metadata list
) {
    fun isSent(): Boolean = direction == "SENT"
    fun isCompleted(): Boolean = status == "COMPLETED"

    fun getFormattedDate(): String {
        return SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(timestamp))
    }

    fun getFormattedTime(): String {
        return SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(timestamp))
    }

    fun getFormattedDateTime(): String {
        return SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(timestamp))
    }

    fun getFormattedDetailedDateTime(): String {
        return SimpleDateFormat("MMMM d, yyyy 'at' h:mm:ss a", Locale.getDefault()).format(Date(timestamp))
    }

    fun getFormattedTotalBytes(): String {
        if (totalBytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(totalBytes.toDouble()) / Math.log10(1024.0)).toInt()
        val index = digitGroups.coerceIn(0, units.size - 1)
        val value = totalBytes / Math.pow(1024.0, index.toDouble())
        return String.format(Locale.US, "%.1f %s", value, units[index])
    }

    fun getFormattedSpeed(): String {
        if (speedBps <= 0) return ""
        val mbps = speedBps.toDouble() / (1024.0 * 1024.0)
        return String.format(Locale.US, "%.1f MB/s", mbps)
    }
}
