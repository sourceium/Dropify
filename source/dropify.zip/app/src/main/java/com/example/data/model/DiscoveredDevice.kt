package com.example.data.model

enum class DeviceConnectionState {
    DISCOVERED,
    CONNECTING,
    AUTHENTICATING,
    CONNECTED,
    REJECTED,
    FAILED,
    DISCONNECTED
}

data class DiscoveredDevice(
    val endpointId: String,
    val name: String,
    val avatarId: Int = 0,
    val connectionState: DeviceConnectionState = DeviceConnectionState.DISCOVERED,
    val authCode: String? = null
)
