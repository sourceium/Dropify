package com.example.data.model

data class FileMetadata(
    val name: String,
    val size: Long,
    val mimeType: String,
    val uri: String = ""
) {
    fun getFormattedSize(): String {
        if (size <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
        val index = digitGroups.coerceIn(0, units.size - 1)
        val value = size / Math.pow(1024.0, index.toDouble())
        return String.format(java.util.Locale.US, "%.1f %s", value, units[index])
    }

    fun getFileExtension(): String {
        val dotIndex = name.lastIndexOf('.')
        return if (dotIndex in 1 until name.length - 1) {
            name.substring(dotIndex + 1).uppercase()
        } else {
            "FILE"
        }
    }

    fun getCategoryName(): String {
        return when {
            mimeType.startsWith("image/") -> "Image"
            mimeType.startsWith("video/") -> "Video"
            mimeType.startsWith("audio/") -> "Audio"
            mimeType.contains("pdf") -> "PDF"
            mimeType.contains("document") || mimeType.contains("text") -> "Document"
            mimeType.contains("android.package-archive") -> "App"
            mimeType.contains("zip") || mimeType.contains("tar") || mimeType.contains("rar") -> "Archive"
            else -> "File"
        }
    }
}
