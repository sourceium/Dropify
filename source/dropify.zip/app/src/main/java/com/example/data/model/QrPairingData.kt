package com.example.data.model

import org.json.JSONObject

data class QrPairingData(
    val deviceName: String,
    val avatarId: Int,
    val endpointId: String,
    val serviceId: String,
    val timestamp: Long,
    val expirationMs: Long = 5 * 60 * 1000L // 5 minutes
) {
    val isExpired: Boolean
        get() = (System.currentTimeMillis() - timestamp) > expirationMs

    fun toJson(): String {
        val json = JSONObject()
        json.put("app", "Dropify")
        json.put("name", deviceName)
        json.put("avatar", avatarId)
        json.put("endpoint", endpointId)
        json.put("service", serviceId)
        json.put("ts", timestamp)
        json.put("exp", expirationMs)
        return json.toString()
    }

    companion object {
        fun fromJson(jsonStr: String): QrPairingData? {
            return try {
                val json = JSONObject(jsonStr)
                val app = json.optString("app")
                if (app != "Dropify" && app != "GlideShare") return null
                QrPairingData(
                    deviceName = json.getString("name"),
                    avatarId = json.optInt("avatar", 0),
                    endpointId = json.getString("endpoint"),
                    serviceId = json.optString("service", "com.HaldarAi.Dropify"),
                    timestamp = json.getLong("ts"),
                    expirationMs = json.optLong("exp", 5 * 60 * 1000L)
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
