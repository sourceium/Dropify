package com.example.data.model

enum class TransferDirection {
    SEND,
    RECEIVE
}

enum class TransferState {
    IDLE,
    WAITING_FOR_ACCEPT,
    ACCEPTED,
    TRANSFERRING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class TransferSession(
    val sessionId: String,
    val direction: TransferDirection,
    val remoteDeviceName: String,
    val remoteAvatarId: Int,
    val files: List<FileItem>,
    val currentFileIndex: Int = 0,
    val bytesTransferred: Long = 0L,
    val totalBytes: Long = 0L,
    val transferSpeedBytesPerSec: Long = 0L,
    val state: TransferState = TransferState.IDLE,
    val errorMessage: String? = null
) {
    val progressFraction: Float
        get() = if (totalBytes > 0) (bytesTransferred.toFloat() / totalBytes).coerceIn(0f, 1f) else 0f

    val progressPercent: Int
        get() = (progressFraction * 100).toInt()

    fun getFormattedSpeed(): String {
        if (transferSpeedBytesPerSec <= 0) return "0 MB/s"
        val mbPerSec = transferSpeedBytesPerSec.toDouble() / (1024 * 1024)
        return if (mbPerSec < 0.1) {
            String.format("%.1f KB/s", transferSpeedBytesPerSec.toDouble() / 1024)
        } else {
            String.format("%.1f MB/s", mbPerSec)
        }
    }

    fun getFormattedRemainingTime(): String {
        if (transferSpeedBytesPerSec <= 0 || totalBytes <= bytesTransferred) return "Calculating..."
        val remainingBytes = totalBytes - bytesTransferred
        val seconds = remainingBytes / transferSpeedBytesPerSec
        return when {
            seconds < 60 -> "${seconds}s"
            seconds < 3600 -> "${seconds / 60}m ${seconds % 60}s"
            else -> "${seconds / 3600}h ${(seconds % 3600) / 60}m"
        }
    }

    fun getFormattedTransferred(): String {
        return "${formatBytes(bytesTransferred)} / ${formatBytes(totalBytes)}"
    }

    companion object {
        fun formatBytes(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
            val index = digitGroups.coerceIn(0, units.size - 1)
            val value = bytes / Math.pow(1024.0, index.toDouble())
            return String.format("%.1f %s", value, units[index])
        }
    }
}
