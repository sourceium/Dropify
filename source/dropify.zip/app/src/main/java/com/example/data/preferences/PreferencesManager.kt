package com.example.data.preferences

import android.content.Context
import android.os.Build
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "dropify_prefs")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val DEVICE_NAME = stringPreferencesKey("device_name")
        val AVATAR_ID = intPreferencesKey("avatar_id")
        val IS_PROFILE_CONFIGURED = booleanPreferencesKey("is_profile_configured")
        val THEME_SETTING = stringPreferencesKey("theme_setting")
        val DEVICE_VISIBILITY = booleanPreferencesKey("device_visibility")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val IS_PRO_PURCHASED = booleanPreferencesKey("is_pro_purchased")
        val RECEIVE_FOLDER = stringPreferencesKey("receive_folder")
    }

    private val defaultDeviceName: String by lazy {
        val model = Build.MODEL
        if (model.isNotBlank()) "$model Dropify" else "Dropify Device"
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            UserPreferences(
                deviceName = prefs[Keys.DEVICE_NAME] ?: defaultDeviceName,
                avatarId = prefs[Keys.AVATAR_ID] ?: 0,
                isProfileConfigured = prefs[Keys.IS_PROFILE_CONFIGURED] ?: false,
                themeSetting = prefs[Keys.THEME_SETTING] ?: "system",
                isDeviceVisible = prefs[Keys.DEVICE_VISIBILITY] ?: true,
                notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
                isProPurchased = prefs[Keys.IS_PRO_PURCHASED] ?: false,
                receiveFolder = prefs[Keys.RECEIVE_FOLDER] ?: "Downloads/Dropify",
                isLoaded = true
            )
        }

    suspend fun isProfileConfigured(): Boolean {
        return try {
            val prefs = context.dataStore.data.first()
            prefs[Keys.IS_PROFILE_CONFIGURED] ?: false
        } catch (_: Exception) {
            false
        }
    }

    suspend fun saveProfile(name: String, avatarId: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DEVICE_NAME] = name.ifBlank { defaultDeviceName }
            prefs[Keys.AVATAR_ID] = avatarId
            prefs[Keys.IS_PROFILE_CONFIGURED] = true
        }
    }

    suspend fun setThemeSetting(theme: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_SETTING] = theme
        }
    }

    suspend fun setDeviceVisibility(visible: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DEVICE_VISIBILITY] = visible
        }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.NOTIFICATIONS_ENABLED] = enabled
        }
    }

    suspend fun setProPurchased(purchased: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.IS_PRO_PURCHASED] = purchased
        }
    }

    suspend fun setReceiveFolder(folder: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.RECEIVE_FOLDER] = folder
        }
    }
}
