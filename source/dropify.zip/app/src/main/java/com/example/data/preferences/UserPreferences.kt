package com.example.data.preferences

data class UserPreferences(
    val deviceName: String,
    val avatarId: Int,
    val isProfileConfigured: Boolean,
    val themeSetting: String, // "system", "light", "dark"
    val isDeviceVisible: Boolean,
    val notificationsEnabled: Boolean,
    val isProPurchased: Boolean,
    val receiveFolder: String,
    val isLoaded: Boolean = true
)
