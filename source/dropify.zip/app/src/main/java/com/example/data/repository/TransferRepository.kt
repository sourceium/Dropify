package com.example.data.repository

import com.example.data.db.TransferDao
import com.example.data.db.TransferEntity
import kotlinx.coroutines.flow.Flow

class TransferRepository(private val transferDao: TransferDao) {

    val allTransfers: Flow<List<TransferEntity>> = transferDao.getAllTransfers()

    fun getTransfersByDirection(direction: String): Flow<List<TransferEntity>> {
        return transferDao.getTransfersByDirection(direction)
    }

    fun getTransfersByStatus(status: String): Flow<List<TransferEntity>> {
        return transferDao.getTransfersByStatus(status)
    }

    fun searchTransfers(query: String): Flow<List<TransferEntity>> {
        return transferDao.searchTransfers(query)
    }

    fun getRecentTransfers(limit: Int): Flow<List<TransferEntity>> {
        return transferDao.getRecentTransfers(limit)
    }

    fun getTransferCount(): Flow<Int> {
        return transferDao.getTransferCount()
    }

    fun getTotalBytesTransferred(): Flow<Long?> {
        return transferDao.getTotalBytesTransferred()
    }

    suspend fun getTransferById(id: Long): TransferEntity? {
        return transferDao.getTransferById(id)
    }

    suspend fun insertTransfer(transfer: TransferEntity): Long {
        return transferDao.insertTransfer(transfer)
    }

    suspend fun insertAll(transfers: List<TransferEntity>) {
        transferDao.insertAll(transfers)
    }

    suspend fun deleteById(id: Long) {
        transferDao.deleteById(id)
    }

    suspend fun clearHistory() {
        transferDao.clearAll()
    }
}
