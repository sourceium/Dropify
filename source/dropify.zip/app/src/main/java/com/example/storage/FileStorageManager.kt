package com.example.storage

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

class FileStorageManager(private val context: Context) {

    /**
     * Creates a temporary .partial file in cache/temp directory for an incoming file.
     */
    fun createPartialFile(fileName: String): File {
        val safeName = sanitizeFileName(fileName)
        val tempDir = File(context.cacheDir, "transfers_incoming").apply { mkdirs() }
        return File(tempDir, "${System.currentTimeMillis()}_${safeName}.partial")
    }

    /**
     * Finalizes the incoming partial file by moving/saving it to public Downloads/Dropify.
     * Returns the finalized Uri or null on error.
     */
    fun finalizeReceivedFile(partialFile: File, originalFileName: String, mimeType: String?): Uri? {
        if (!partialFile.exists() || partialFile.length() <= 0) {
            partialFile.delete()
            return null
        }

        val safeName = sanitizeFileName(originalFileName)
        val resolvedMime = mimeType ?: getMimeTypeForName(safeName)

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Use MediaStore to save directly to Downloads/Dropify
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                    put(MediaStore.MediaColumns.MIME_TYPE, resolvedMime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/Dropify")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val targetUri = context.contentResolver.insert(collection, contentValues)

                if (targetUri != null) {
                    context.contentResolver.openOutputStream(targetUri)?.use { outStream ->
                        FileInputStream(partialFile).use { inStream ->
                            copyStream(inStream, outStream)
                        }
                    }

                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    context.contentResolver.update(targetUri, contentValues, null, null)

                    partialFile.delete()
                    targetUri
                } else {
                    fallbackSaveToFilesDir(partialFile, safeName)
                }
            } else {
                fallbackSaveToDownloads(partialFile, safeName)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            fallbackSaveToFilesDir(partialFile, safeName)
        }
    }

    private fun fallbackSaveToDownloads(partialFile: File, fileName: String): Uri? {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val targetDir = File(downloadsDir, "Dropify").apply { mkdirs() }
        var targetFile = File(targetDir, fileName)
        var counter = 1
        while (targetFile.exists()) {
            val nameWithoutExt = fileName.substringBeforeLast(".")
            val ext = fileName.substringAfterLast(".", "")
            val newName = if (ext.isNotEmpty()) "$nameWithoutExt ($counter).$ext" else "$nameWithoutExt ($counter)"
            targetFile = File(targetDir, newName)
            counter++
        }

        return try {
            FileInputStream(partialFile).use { inStream ->
                FileOutputStream(targetFile).use { outStream ->
                    copyStream(inStream, outStream)
                }
            }
            partialFile.delete()
            Uri.fromFile(targetFile)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun fallbackSaveToFilesDir(partialFile: File, fileName: String): Uri? {
        val appDir = File(context.getExternalFilesDir(null), "Received").apply { mkdirs() }
        var targetFile = File(appDir, fileName)
        var counter = 1
        while (targetFile.exists()) {
            val nameWithoutExt = fileName.substringBeforeLast(".")
            val ext = fileName.substringAfterLast(".", "")
            val newName = if (ext.isNotEmpty()) "$nameWithoutExt ($counter).$ext" else "$nameWithoutExt ($counter)"
            targetFile = File(appDir, newName)
            counter++
        }

        return try {
            FileInputStream(partialFile).use { inStream ->
                FileOutputStream(targetFile).use { outStream ->
                    copyStream(inStream, outStream)
                }
            }
            partialFile.delete()
            Uri.fromFile(targetFile)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun copyStream(inStream: InputStream, outStream: OutputStream) {
        val buffer = ByteArray(64 * 1024) // 64 KB buffer for streaming
        var bytesRead: Int
        while (inStream.read(buffer).also { bytesRead = it } != -1) {
            outStream.write(buffer, 0, bytesRead)
        }
        outStream.flush()
    }

    fun sanitizeFileName(name: String): String {
        return name.replace("[\\\\/:*?\"<>|]".toRegex(), "_").trim().ifBlank { "file_${System.currentTimeMillis()}" }
    }

    fun getMimeTypeForName(name: String): String {
        val ext = MimeTypeMap.getFileExtensionFromUrl(name) ?: ""
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "application/octet-stream"
    }
}
