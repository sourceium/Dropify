package com.example.transport

data class ConnectionRequest(
    val endpointId: String,
    val endpointName: String,
    val authenticationDigits: String,
    val isIncomingConnection: Boolean
)
