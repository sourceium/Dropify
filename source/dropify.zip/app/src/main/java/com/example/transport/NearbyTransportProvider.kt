package com.example.transport

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Log
import com.example.data.model.DeviceConnectionState
import com.example.data.model.DiscoveredDevice
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import java.io.File

class NearbyTransportProvider(
    private val context: Context,
    private val listener: TransportProviderListener
) : TransportProvider {

    private val client: ConnectionsClient = Nearby.getConnectionsClient(context)
    private val strategy = Strategy.P2P_STAR
    private val serviceId = "com.HaldarAi.Dropify"

    override var isAdvertising: Boolean = false
        private set

    override var isDiscovering: Boolean = false
        private set

    private val incomingFilePayloads = mutableMapOf<Long, Payload>()

    // Serializes device info into endpointName string: "Dropify|<avatarId>|<name>"
    private fun formatEndpointName(name: String, avatarId: Int): String {
        return "Dropify|$avatarId|$name"
    }

    private fun parseEndpointName(raw: String): Pair<String, Int> {
        val parts = raw.split("|")
        return if (parts.size >= 3 && (parts[0] == "Dropify" || parts[0] == "GlideShare")) {
            val avatarId = parts[1].toIntOrNull() ?: 0
            val name = parts.subList(2, parts.size).joinToString("|")
            Pair(name, avatarId)
        } else {
            Pair(raw, 0)
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            val (name, _) = parseEndpointName(info.endpointName)
            val request = ConnectionRequest(
                endpointId = endpointId,
                endpointName = name,
                authenticationDigits = info.authenticationDigits,
                isIncomingConnection = info.isIncomingConnection
            )
            listener.onConnectionInitiated(request)
        }

        override fun onConnectionResult(endpointId: String, resolution: ConnectionResolution) {
            when (resolution.status.statusCode) {
                ConnectionsStatusCodes.STATUS_OK -> {
                    listener.onConnected(endpointId)
                }
                ConnectionsStatusCodes.STATUS_CONNECTION_REJECTED -> {
                    listener.onError("Connection declined by remote device")
                    listener.onDisconnected(endpointId)
                }
                else -> {
                    listener.onError("Connection failed: ${resolution.status.statusMessage ?: "Error"}")
                    listener.onDisconnected(endpointId)
                }
            }
        }

        override fun onDisconnected(endpointId: String) {
            listener.onDisconnected(endpointId)
        }
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            if (info.serviceId == serviceId) {
                val (name, avatarId) = parseEndpointName(info.endpointName)
                val device = DiscoveredDevice(
                    endpointId = endpointId,
                    name = name,
                    avatarId = avatarId,
                    connectionState = DeviceConnectionState.DISCOVERED
                )
                listener.onDeviceFound(device)
            }
        }

        override fun onEndpointLost(endpointId: String) {
            listener.onDeviceLost(endpointId)
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> {
                    val bytes = payload.asBytes()
                    if (bytes != null) {
                        val str = String(bytes, Charsets.UTF_8)
                        listener.onMetadataReceived(endpointId, str)
                    }
                }
                Payload.Type.FILE -> {
                    incomingFilePayloads[payload.id] = payload
                }
                Payload.Type.STREAM -> {}
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            listener.onPayloadTransferUpdate(
                endpointId = endpointId,
                payloadId = update.payloadId,
                bytesTransferred = update.bytesTransferred,
                totalBytes = update.totalBytes,
                status = update.status
            )

            if (update.status == PayloadTransferUpdate.Status.SUCCESS) {
                val filePayload = incomingFilePayloads.remove(update.payloadId)
                if (filePayload != null && filePayload.type == Payload.Type.FILE) {
                    val javaFile = filePayload.asFile()?.asJavaFile()
                    if (javaFile != null) {
                        listener.onFilePayloadReceived(endpointId, update.payloadId, javaFile)
                    }
                }
            } else if (update.status == PayloadTransferUpdate.Status.FAILURE ||
                       update.status == PayloadTransferUpdate.Status.CANCELED) {
                incomingFilePayloads.remove(update.payloadId)
            }
        }
    }

    override fun startAdvertising(deviceName: String, avatarId: Int) {
        try {
            val endpointName = formatEndpointName(deviceName, avatarId)
            val options = AdvertisingOptions.Builder().setStrategy(strategy).build()

            client.startAdvertising(endpointName, serviceId, connectionLifecycleCallback, options)
                .addOnSuccessListener {
                    isAdvertising = true
                }
                .addOnFailureListener { e ->
                    isAdvertising = false
                    listener.onError("Advertising failed: ${e.localizedMessage ?: "Unknown error"}")
                }
        } catch (e: Exception) {
            isAdvertising = false
            listener.onError("Unable to advertise: ${e.localizedMessage ?: "Permissions or Bluetooth required"}")
        }
    }

    override fun stopAdvertising() {
        try {
            client.stopAdvertising()
        } catch (_: Exception) {}
        isAdvertising = false
    }

    override fun startDiscovery() {
        try {
            val options = DiscoveryOptions.Builder().setStrategy(strategy).build()

            client.startDiscovery(serviceId, endpointDiscoveryCallback, options)
                .addOnSuccessListener {
                    isDiscovering = true
                }
                .addOnFailureListener { e ->
                    isDiscovering = false
                    listener.onError("Discovery failed: ${e.localizedMessage ?: "Unknown error"}")
                }
        } catch (e: Exception) {
            isDiscovering = false
            listener.onError("Unable to discover: ${e.localizedMessage ?: "Permissions or Wi-Fi required"}")
        }
    }

    override fun stopDiscovery() {
        try {
            client.stopDiscovery()
        } catch (_: Exception) {}
        isDiscovering = false
    }

    override fun connect(endpointId: String, deviceName: String, avatarId: Int) {
        try {
            val endpointName = formatEndpointName(deviceName, avatarId)
            client.requestConnection(endpointName, endpointId, connectionLifecycleCallback)
                .addOnFailureListener { e ->
                    listener.onError("Connection request failed: ${e.localizedMessage ?: "Error"}")
                }
        } catch (e: Exception) {
            listener.onError("Connection failed: ${e.localizedMessage}")
        }
    }

    override fun acceptConnection(endpointId: String) {
        try {
            client.acceptConnection(endpointId, payloadCallback)
                .addOnFailureListener { e ->
                    listener.onError("Accept connection failed: ${e.localizedMessage ?: "Error"}")
                }
        } catch (e: Exception) {
            listener.onError("Accept failed: ${e.localizedMessage}")
        }
    }

    override fun rejectConnection(endpointId: String) {
        try {
            client.rejectConnection(endpointId)
        } catch (_: Exception) {}
    }

    override fun disconnect(endpointId: String) {
        try {
            client.disconnectFromEndpoint(endpointId)
        } catch (_: Exception) {}
    }

    override fun stopAll() {
        try {
            client.stopAllEndpoints()
        } catch (_: Exception) {}
        isAdvertising = false
        isDiscovering = false
        incomingFilePayloads.clear()
    }

    override fun sendMetadata(endpointId: String, json: String): Long {
        return try {
            val payload = Payload.fromBytes(json.toByteArray(Charsets.UTF_8))
            client.sendPayload(endpointId, payload)
            payload.id
        } catch (e: Exception) {
            Log.e("NearbyTransport", "Error sending metadata", e)
            -1L
        }
    }

    override fun sendFile(endpointId: String, fileUri: Uri): Long? {
        return try {
            val pfd: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(fileUri, "r")
                ?: return null
            val payload = Payload.fromFile(pfd)
            client.sendPayload(endpointId, payload)
            payload.id
        } catch (e: Exception) {
            Log.e("NearbyTransport", "Error sending file payload", e)
            null
        }
    }
}
