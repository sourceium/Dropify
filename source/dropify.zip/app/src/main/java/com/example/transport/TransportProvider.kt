package com.example.transport

import com.example.data.model.DiscoveredDevice
import java.io.File

interface TransportProviderListener {
    fun onDeviceFound(device: DiscoveredDevice)
    fun onDeviceLost(endpointId: String)
    fun onConnectionInitiated(request: ConnectionRequest)
    fun onConnected(endpointId: String)
    fun onDisconnected(endpointId: String)
    fun onPayloadTransferUpdate(endpointId: String, payloadId: Long, bytesTransferred: Long, totalBytes: Long, status: Int)
    fun onMetadataReceived(endpointId: String, metadataJson: String)
    fun onFilePayloadReceived(endpointId: String, payloadId: Long, incomingFile: File)
    fun onError(message: String)
}

interface TransportProvider {
    val isAdvertising: Boolean
    val isDiscovering: Boolean

    fun startAdvertising(deviceName: String, avatarId: Int)
    fun stopAdvertising()

    fun startDiscovery()
    fun stopDiscovery()

    fun connect(endpointId: String, deviceName: String, avatarId: Int)
    fun acceptConnection(endpointId: String)
    fun rejectConnection(endpointId: String)
    fun disconnect(endpointId: String)
    fun stopAll()

    fun sendMetadata(endpointId: String, json: String): Long
    fun sendFile(endpointId: String, fileUri: android.net.Uri): Long?
}
