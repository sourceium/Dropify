package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AnekLatinFontFamily
import com.example.ui.theme.DesignTokens

/**
 * Official App Logo with full filled background #4d43fe and bold centered "Df" text in #ffffff
 * styled with the requested CSS design token font (Anek Latin) and radius (sm · 6).
 */
@Composable
fun AppLogo(
    size: Dp = 48.dp,
    shape: Shape = RoundedCornerShape(DesignTokens.RadiusMd),
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(Color(0xFF4D43FE)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "Df",
            color = Color.White,
            fontFamily = AnekLatinFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.52f).sp,
            lineHeight = (size.value * 0.52f).sp,
            textAlign = TextAlign.Center
        )
    }
}
