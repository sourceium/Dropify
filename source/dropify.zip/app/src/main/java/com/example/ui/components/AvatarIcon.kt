package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Landscape
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DesignTokens

data class AvatarDefinition(
    val id: Int,
    val name: String,
    val icon: ImageVector,
    val gradientColors: List<Color>
)

object AvatarCatalog {
    val avatars = listOf(
        AvatarDefinition(0, "Rocket", Icons.Default.RocketLaunch, listOf(DesignTokens.BrandPrimary, DesignTokens.RampPrimary400)),
        AvatarDefinition(1, "Lightning", Icons.Default.Bolt, listOf(Color(0xFFFF9F1C), Color(0xFFFFBF69))),
        AvatarDefinition(2, "Compass", Icons.Default.Explore, listOf(Color(0xFF2EC4B6), Color(0xFFCBF3F0))),
        AvatarDefinition(3, "Sun", Icons.Default.WbSunny, listOf(Color(0xFFFF5400), Color(0xFFFF9E00))),
        AvatarDefinition(4, "Night", Icons.Default.Nightlight, listOf(DesignTokens.RampPrimary800, DesignTokens.RampPrimary500)),
        AvatarDefinition(5, "Fire", Icons.Default.LocalFireDepartment, listOf(Color(0xFFE63946), Color(0xFFFF758F))),
        AvatarDefinition(6, "Mountain", Icons.Default.Landscape, listOf(Color(0xFF00C48C), Color(0xFF70E000))),
        AvatarDefinition(7, "Diamond", Icons.Default.Diamond, listOf(DesignTokens.RampPrimary700, Color(0xFF00B4D8))),
        AvatarDefinition(8, "Shield", Icons.Default.Security, listOf(DesignTokens.NeutralN200, DesignTokens.NeutralN500)),
        AvatarDefinition(9, "Flight", Icons.Default.Flight, listOf(Color(0xFF0077B6), Color(0xFF90E0EF))),
        AvatarDefinition(10, "Heart", Icons.Default.Favorite, listOf(Color(0xFFFF006E), Color(0xFFFF85A1))),
        AvatarDefinition(11, "Paws", Icons.Default.Pets, listOf(DesignTokens.RampPrimary900, DesignTokens.RampPrimary400))
    )

    fun getAvatar(id: Int): AvatarDefinition {
        return avatars.getOrNull(id) ?: avatars[0]
    }
}

@Composable
fun AvatarIcon(
    avatarId: Int,
    size: Dp = 48.dp,
    isSelected: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val def = AvatarCatalog.getAvatar(avatarId)
    val baseModifier = modifier
        .size(size)
        .clip(CircleShape)
        .background(Brush.linearGradient(def.gradientColors))
        .then(
            if (isSelected) {
                Modifier.border(3.dp, DesignTokens.BrandPrimary, CircleShape)
            } else {
                Modifier
            }
        )
        .then(
            if (onClick != null) {
                Modifier.clickable { onClick() }
            } else {
                Modifier
            }
        )

    Box(
        modifier = baseModifier,
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = def.icon,
            contentDescription = def.name,
            tint = Color.White,
            modifier = Modifier.size(size * 0.55f)
        )
    }
}
