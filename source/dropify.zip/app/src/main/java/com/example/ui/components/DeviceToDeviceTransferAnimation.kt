package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DesignTokens
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun DeviceToDeviceTransferAnimation(
    senderName: String,
    senderAvatarId: Int,
    receiverName: String,
    receiverAvatarId: Int,
    progressFraction: Float,
    transferSpeedBps: Long,
    currentFileName: String?,
    currentFileType: String?,
    modifier: Modifier = Modifier
) {
    // Smooth progress interpolation
    val animatedProgress by animateFloatAsState(
        targetValue = progressFraction.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
        label = "animatedProgress"
    )

    // Infinite transitions for continuous fluid motion
    val infiniteTransition = rememberInfiniteTransition(label = "transferBeams")

    // Particle flight cycle (0f to 1f)
    val flightPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "flightPhase"
    )

    // Sender wave pulsation (0f to 1f)
    val senderPulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "senderPulse"
    )

    // Receiver absorption pulsation
    val receiverPulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "receiverPulse"
    )

    // Gentle floating wobble for flying packet
    val wobbleFloat by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wobbleFloat"
    )

    Surface(
        shape = RoundedCornerShape(DesignTokens.RadiusXl),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        modifier = modifier
            .fillMaxWidth()
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                RoundedCornerShape(DesignTokens.RadiusXl)
            )
            .testTag("transfer_animation_container")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = DesignTokens.Spacing20, horizontal = DesignTokens.Spacing16),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Devices & Beaming Bridge Row
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                contentAlignment = Alignment.Center
            ) {
                val trackOutlineColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)

                // Background Animated Canvas Drawing the Beaming Particle Stream
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val nodeRadius = 38.dp.toPx()
                    val yCenter = size.height / 2f
                    val xSender = nodeRadius + 10.dp.toPx()
                    val xReceiver = size.width - nodeRadius - 10.dp.toPx()
                    val beamDistance = xReceiver - xSender

                    // 1. Radar wave expanding from Sender
                    val senderRingRadius = nodeRadius + (senderPulse * 28.dp.toPx())
                    val senderRingAlpha = (1f - senderPulse).coerceIn(0f, 1f) * 0.45f
                    drawCircle(
                        color = DesignTokens.ColorPrimary.copy(alpha = senderRingAlpha),
                        radius = senderRingRadius,
                        center = Offset(xSender, yCenter),
                        style = Stroke(width = 2.5.dp.toPx())
                    )

                    // 2. Absorption wave at Receiver
                    val receiverRingRadius = nodeRadius + (receiverPulse * 24.dp.toPx())
                    val receiverRingAlpha = (1f - receiverPulse).coerceIn(0f, 1f) * 0.40f
                    drawCircle(
                        color = Color(0xFF00C48C).copy(alpha = receiverRingAlpha),
                        radius = receiverRingRadius,
                        center = Offset(xReceiver, yCenter),
                        style = Stroke(width = 2.5.dp.toPx())
                    )

                    // 3. Static guide dashed track
                    drawLine(
                        color = trackOutlineColor,
                        start = Offset(xSender, yCenter),
                        end = Offset(xReceiver, yCenter),
                        strokeWidth = 3.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f), 0f),
                        cap = StrokeCap.Round
                    )

                    // 4. Progress active beam with vibrant gradient
                    val progressEndX = xSender + (beamDistance * animatedProgress)
                    if (progressEndX > xSender) {
                        drawLine(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    DesignTokens.ColorPrimary,
                                    DesignTokens.RampPrimary400,
                                    Color(0xFF00C48C)
                                ),
                                startX = xSender,
                                endX = progressEndX
                            ),
                            start = Offset(xSender, yCenter),
                            end = Offset(progressEndX, yCenter),
                            strokeWidth = 5.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }

                    // 5. Streaming photon energy packets traveling along the beam
                    val particleCount = 5
                    for (i in 0 until particleCount) {
                        val phase = (flightPhase + (i.toFloat() / particleCount)) % 1f
                        val particleX = xSender + (beamDistance * phase)
                        // Gentle sine arc trajectory
                        val arcOffset = sin(phase * PI.toFloat()) * 16.dp.toPx()
                        val particleY = yCenter - arcOffset
                        val particleAlpha = sin(phase * PI.toFloat()).coerceIn(0f, 1f)

                        // Particle trail & glow
                        drawCircle(
                            color = DesignTokens.ColorPrimary.copy(alpha = particleAlpha * 0.35f),
                            radius = 6.dp.toPx(),
                            center = Offset(particleX, particleY)
                        )
                        drawCircle(
                            color = Color.White.copy(alpha = particleAlpha * 0.95f),
                            radius = 2.5.dp.toPx(),
                            center = Offset(particleX, particleY)
                        )
                    }
                }

                // Foreground Row with Sender Node, Flying File Capsule, and Receiver Node
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // SENDER NODE
                    DeviceNode(
                        label = "Sender",
                        deviceName = senderName,
                        avatarId = senderAvatarId,
                        accentColor = DesignTokens.ColorPrimary,
                        isSource = true
                    )

                    // RECEIVER NODE
                    DeviceNode(
                        label = "Receiver",
                        deviceName = receiverName,
                        avatarId = receiverAvatarId,
                        accentColor = Color(0xFF00C48C),
                        isSource = false
                    )
                }

                // Flying File Capsule in the middle bridging zone
                val fileIcon = getCategoryIcon(currentFileType)
                Box(
                    modifier = Modifier
                        .offset {
                            // Translate slightly with wobble
                            IntOffset(
                                x = 0,
                                y = (-sin(flightPhase * PI.toFloat()) * 16.dp.toPx() + wobbleFloat.dp.toPx()).roundToInt()
                            )
                        }
                        .scale(0.95f + (0.05f * sin(flightPhase * PI.toFloat())))
                        .rotate(wobbleFloat * 0.8f)
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(DesignTokens.ColorPrimary, DesignTokens.RampPrimary700)
                            ),
                            shape = RoundedCornerShape(DesignTokens.RadiusMd)
                        )
                        .shadow(6.dp, RoundedCornerShape(DesignTokens.RadiusMd), ambientColor = DesignTokens.ColorPrimary)
                        .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(DesignTokens.RadiusMd))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = fileIcon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing16))

            // Smooth Animated Transition of the Current File Name
            AnimatedContent(
                targetState = currentFileName ?: "Transferring files...",
                transitionSpec = {
                    (slideInHorizontally { width -> width / 2 } + fadeIn())
                        .togetherWith(slideOutHorizontally { width -> -width / 2 } + fadeOut())
                },
                label = "currentFileTransition"
            ) { targetName ->
                Row(
                    modifier = Modifier
                        .background(
                            DesignTokens.ColorBg3,
                            RoundedCornerShape(DesignTokens.RadiusMd)
                        )
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = getCategoryIcon(currentFileType),
                        contentDescription = null,
                        tint = DesignTokens.ColorPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = targetName,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun DeviceNode(
    label: String,
    deviceName: String,
    avatarId: Int,
    accentColor: Color,
    isSource: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(86.dp)
    ) {
        Box(
            modifier = Modifier
                .size(62.dp)
                .background(accentColor.copy(alpha = 0.12f), CircleShape)
                .border(2.dp, accentColor, CircleShape)
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            AvatarIcon(avatarId = avatarId, size = 52.dp)
        }

        Spacer(modifier = Modifier.height(6.dp))

        Box(
            modifier = Modifier
                .background(accentColor.copy(alpha = 0.12f), RoundedCornerShape(DesignTokens.RadiusMd))
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = accentColor,
                fontSize = 10.sp
            )
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = deviceName,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

private fun getCategoryIcon(mimeType: String?): ImageVector {
    if (mimeType == null) return Icons.Default.Description
    return when {
        mimeType.startsWith("image/") -> Icons.Default.Image
        mimeType.startsWith("video/") -> Icons.Default.Videocam
        mimeType.startsWith("audio/") -> Icons.Default.Audiotrack
        else -> Icons.Default.Description
    }
}
