package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.model.FileItem
import com.example.data.model.TransferSession
import com.example.transport.ConnectionRequest
import com.example.ui.theme.DesignTokens

@Composable
fun IncomingTransferDialog(
    request: ConnectionRequest,
    incomingFiles: List<FileItem>,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    val totalBytes = incomingFiles.sumOf { it.size }
    val formattedTotal = TransferSession.formatBytes(totalBytes)

    Dialog(
        onDismissRequest = onDecline,
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Surface(
            shape = RoundedCornerShape(DesignTokens.RadiusR3),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(DesignTokens.RadiusR3))
        ) {
            Column(
                modifier = Modifier.padding(DesignTokens.SpacingS4),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .background(
                            DesignTokens.BackgroundBg3,
                            RoundedCornerShape(DesignTokens.RadiusR3)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FileDownload,
                        contentDescription = null,
                        tint = DesignTokens.BrandPrimary,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(DesignTokens.SpacingS3))

                Text(
                    text = stringResource(id = R.string.incoming_transfer),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(DesignTokens.SpacingS1))

                Text(
                    text = stringResource(id = R.string.transfer_from, request.endpointName),
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (incomingFiles.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(DesignTokens.SpacingS1))
                    Box(
                        modifier = Modifier
                            .background(DesignTokens.BackgroundBg3, RoundedCornerShape(DesignTokens.RadiusR5))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = stringResource(id = R.string.transfer_details, incomingFiles.size, formattedTotal),
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = DesignTokens.BrandPrimary
                        )
                    }
                }

                if (request.authenticationDigits.isNotBlank()) {
                    Spacer(modifier = Modifier.height(DesignTokens.SpacingS2))
                    Text(
                        text = "PIN: ${request.authenticationDigits}",
                        style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 2.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }

                Spacer(modifier = Modifier.height(DesignTokens.SpacingS4))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(DesignTokens.SpacingS2)
                ) {
                    OutlinedButton(
                        onClick = onDecline,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(DesignTokens.RadiusR5),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            stringResource(id = R.string.decline),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onAccept,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(DesignTokens.RadiusR5),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DesignTokens.ActionPrimary,
                            contentColor = DesignTokens.ActionOnPrimary
                        )
                    ) {
                        Text(
                            stringResource(id = R.string.accept),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
