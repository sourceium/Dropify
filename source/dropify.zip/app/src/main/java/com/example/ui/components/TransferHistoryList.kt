package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.TransferEntity
import com.example.data.model.FileMetadata
import com.example.ui.theme.DesignTokens
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class HistoryFilter {
    ALL, SENT, RECEIVED, COMPLETED
}

@Composable
fun TransferHistoryList(
    transfers: List<TransferEntity>,
    onItemClick: (TransferEntity) -> Unit,
    onDeleteTransfer: ((Long) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(HistoryFilter.ALL) }
    var transferToDelete by remember { mutableStateOf<TransferEntity?>(null) }

    // Filtered transfers based on chip and search query
    val filteredTransfers by remember(transfers, searchQuery, selectedFilter) {
        derivedStateOf {
            transfers.filter { entity ->
                val matchesFilter = when (selectedFilter) {
                    HistoryFilter.ALL -> true
                    HistoryFilter.SENT -> entity.isSent()
                    HistoryFilter.RECEIVED -> !entity.isSent()
                    HistoryFilter.COMPLETED -> entity.isCompleted()
                }

                val matchesSearch = if (searchQuery.isBlank()) {
                    true
                } else {
                    val query = searchQuery.trim().lowercase(Locale.ROOT)
                    entity.deviceName.lowercase(Locale.ROOT).contains(query) ||
                            entity.fileNames.lowercase(Locale.ROOT).contains(query) ||
                            entity.files.any { it.name.lowercase(Locale.ROOT).contains(query) }
                }

                matchesFilter && matchesSearch
            }
        }
    }

    // Grouping by relative date string (Today, Yesterday, Date)
    val groupedTransfers by remember(filteredTransfers) {
        derivedStateOf {
            filteredTransfers.groupBy { entity ->
                getRelativeDateHeader(entity.timestamp)
            }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = DesignTokens.Spacing16, vertical = DesignTokens.Spacing4)
                .testTag("history_search_input"),
            placeholder = {
                Text(
                    text = "Search by file or device name...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = DesignTokens.ColorPrimary
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear search",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(DesignTokens.RadiusXl),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = DesignTokens.ColorPrimary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            )
        )

        // Filter chips row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = DesignTokens.Spacing16, vertical = DesignTokens.Spacing8),
            horizontalArrangement = Arrangement.spacedBy(DesignTokens.Spacing8)
        ) {
            val allCount = transfers.size
            val sentCount = transfers.count { it.isSent() }
            val receivedCount = transfers.count { !it.isSent() }
            val completedCount = transfers.count { it.isCompleted() }

            HistoryFilterChip(
                label = "All ($allCount)",
                selected = selectedFilter == HistoryFilter.ALL,
                onClick = { selectedFilter = HistoryFilter.ALL },
                testTag = "filter_chip_all"
            )
            HistoryFilterChip(
                label = "Sent ($sentCount)",
                selected = selectedFilter == HistoryFilter.SENT,
                onClick = { selectedFilter = HistoryFilter.SENT },
                testTag = "filter_chip_sent"
            )
            HistoryFilterChip(
                label = "Received ($receivedCount)",
                selected = selectedFilter == HistoryFilter.RECEIVED,
                onClick = { selectedFilter = HistoryFilter.RECEIVED },
                testTag = "filter_chip_received"
            )
            HistoryFilterChip(
                label = "Completed ($completedCount)",
                selected = selectedFilter == HistoryFilter.COMPLETED,
                onClick = { selectedFilter = HistoryFilter.COMPLETED },
                testTag = "filter_chip_completed"
            )
        }

        // List Content or Empty State
        if (filteredTransfers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(DesignTokens.Spacing24),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .background(DesignTokens.ColorBg3, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = DesignTokens.ColorPrimary,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(DesignTokens.Spacing16))
                    Text(
                        text = if (searchQuery.isNotEmpty() || selectedFilter != HistoryFilter.ALL) {
                            "No transfers found"
                        } else {
                            "No transfer history yet"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (searchQuery.isNotEmpty()) {
                            "Try searching with a different file or device name."
                        } else {
                            "Files you send or receive will appear here with detailed metadata."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (searchQuery.isNotEmpty() || selectedFilter != HistoryFilter.ALL) {
                        Spacer(modifier = Modifier.height(DesignTokens.Spacing12))
                        TextButton(onClick = {
                            searchQuery = ""
                            selectedFilter = HistoryFilter.ALL
                        }) {
                            Text("Reset filters", color = DesignTokens.ColorPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = DesignTokens.Spacing16),
                verticalArrangement = Arrangement.spacedBy(DesignTokens.Spacing12)
            ) {
                groupedTransfers.forEach { (dateHeader, itemsInGroup) ->
                    item(key = "header_$dateHeader") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = DesignTokens.Spacing12, bottom = DesignTokens.Spacing4),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = dateHeader,
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(DesignTokens.Spacing8))
                            Box(
                                modifier = Modifier
                                    .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${itemsInGroup.size}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    items(itemsInGroup, key = { it.id }) { item ->
                        TransferHistoryItemCard(
                            item = item,
                            onClick = { onItemClick(item) },
                            onDelete = if (onDeleteTransfer != null) {
                                { transferToDelete = item }
                            } else null
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(DesignTokens.Spacing24))
                }
            }
        }
    }

    // Delete single transfer dialog
    transferToDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { transferToDelete = null },
            title = {
                Text(
                    text = "Delete Transfer Record",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text("Are you sure you want to remove this transfer record from your history?")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteTransfer?.invoke(target.id)
                        transferToDelete = null
                    }
                ) {
                    Text(
                        text = "Delete",
                        color = Color(0xFFFF4861),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { transferToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun HistoryFilterChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = {
            Text(
                text = label,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
        },
        shape = RoundedCornerShape(DesignTokens.RadiusMd),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = DesignTokens.ColorPrimary,
            selectedLabelColor = Color.White,
            containerColor = MaterialTheme.colorScheme.surface,
            labelColor = MaterialTheme.colorScheme.onSurface
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = if (selected) DesignTokens.ColorPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
            selectedBorderColor = DesignTokens.ColorPrimary
        ),
        modifier = Modifier.testTag(testTag)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TransferHistoryItemCard(
    item: TransferEntity,
    onClick: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    val isSent = item.isSent()
    val formattedTotal = item.getFormattedTotalBytes()
    val formattedTime = item.getFormattedTime()
    val formattedSpeed = item.getFormattedSpeed()

    Surface(
        shape = RoundedCornerShape(DesignTokens.RadiusXl),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DesignTokens.RadiusXl))
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                RoundedCornerShape(DesignTokens.RadiusXl)
            )
            .clickable { onClick() }
            .testTag("history_item_${item.id}")
    ) {
        Column(modifier = Modifier.padding(DesignTokens.Spacing16)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Direction icon container
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(
                            if (isSent) DesignTokens.ColorBg3 else Color(0xFF2C2C34),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isSent) Icons.Default.FileUpload else Icons.Default.FileDownload,
                        contentDescription = if (isSent) "Sent" else "Received",
                        tint = if (isSent) DesignTokens.ColorPrimary else Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(DesignTokens.Spacing12))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${if (isSent) "Sent to" else "Received from"} ${item.deviceName}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "$formattedTime • $formattedTotal • ${item.fileCount} file${if (item.fileCount != 1) "s" else ""}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Status chip
                Box(
                    modifier = Modifier
                        .background(
                            when (item.status) {
                                "COMPLETED" -> Color(0xFF00C48C).copy(alpha = 0.15f)
                                "CANCELLED" -> MaterialTheme.colorScheme.surfaceVariant
                                else -> Color(0xFFFF4861).copy(alpha = 0.15f)
                            },
                            RoundedCornerShape(DesignTokens.RadiusMd)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = when (item.status) {
                            "COMPLETED" -> "Success"
                            "CANCELLED" -> "Cancelled"
                            else -> "Failed"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = when (item.status) {
                            "COMPLETED" -> Color(0xFF00C48C)
                            "CANCELLED" -> MaterialTheme.colorScheme.onSurfaceVariant
                            else -> Color(0xFFFF4861)
                        }
                    )
                }

                if (onDelete != null) {
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("delete_history_${item.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete record",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Transfer metrics & file preview snippet
            if (item.files.isNotEmpty() || formattedSpeed.isNotEmpty()) {
                Spacer(modifier = Modifier.height(DesignTokens.Spacing12))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Preview of first 2 files with extension badges
                    FlowRow(
                        modifier = Modifier.weight(1f, fill = false),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        item.files.take(2).forEach { file ->
                            FileMiniBadge(file = file)
                        }
                        if (item.files.size > 2) {
                            Box(
                                modifier = Modifier
                                    .background(
                                        MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(DesignTokens.RadiusMd)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "+${item.files.size - 2} more",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Speed indicator if available
                    if (formattedSpeed.isNotEmpty()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = null,
                                tint = DesignTokens.ColorPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = formattedSpeed,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = DesignTokens.ColorPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FileMiniBadge(file: FileMetadata) {
    val ext = file.getFileExtension()
    Box(
        modifier = Modifier
            .background(
                DesignTokens.ColorBg3,
                RoundedCornerShape(DesignTokens.RadiusMd)
            )
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = ext,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                color = DesignTokens.ColorPrimary,
                fontSize = 10.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = file.name,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 120.dp),
                fontSize = 11.sp
            )
        }
    }
}

// Relative date helper
private fun getRelativeDateHeader(timestamp: Long): String {
    val recordCalendar = Calendar.getInstance().apply { timeInMillis = timestamp }
    val nowCalendar = Calendar.getInstance()

    val recordYear = recordCalendar.get(Calendar.YEAR)
    val nowYear = nowCalendar.get(Calendar.YEAR)
    val recordDay = recordCalendar.get(Calendar.DAY_OF_YEAR)
    val nowDay = nowCalendar.get(Calendar.DAY_OF_YEAR)

    return when {
        recordYear == nowYear && recordDay == nowDay -> "Today"
        recordYear == nowYear && recordDay == nowDay - 1 -> "Yesterday"
        recordYear == nowYear && nowDay - recordDay in 2..6 -> "This Week"
        else -> SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()).format(Date(timestamp))
    }
}
