package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object ProfileSetup : Screen("profile_setup")
    object Home : Screen("home")
    object SendFilePicker : Screen("send_file_picker")
    object SendReview : Screen("send_review")
    object DeviceDiscovery : Screen("device_discovery")
    object ReceiveWaiting : Screen("receive_waiting")
    object TransferProgress : Screen("transfer_progress")
    object TransferComplete : Screen("transfer_complete")
    object History : Screen("history")
    object HistoryDetail : Screen("history_detail/{id}") {
        fun createRoute(id: Long) = "history_detail/$id"
    }
    object Settings : Screen("settings")
    object ProfileEdit : Screen("profile_edit")
    object QrDisplay : Screen("qr_display")
    object QrScan : Screen("qr_scan")
}
