package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.DeviceConnectionState
import com.example.data.model.DiscoveredDevice
import com.example.ui.components.AvatarIcon
import com.example.ui.theme.DesignTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceDiscoveryScreen(
    discoveredDevices: List<DiscoveredDevice>,
    onStartDiscovery: () -> Unit,
    onStopDiscovery: () -> Unit,
    onDeviceSelected: (DiscoveredDevice) -> Unit,
    onScanQrClick: () -> Unit,
    onBackClick: () -> Unit
) {
    DisposableEffect(Unit) {
        onStartDiscovery()
        onDispose {
            onStopDiscovery()
        }
    }

    val transition = rememberInfiniteTransition(label = "radarPulse")
    val pulseScale1 by transition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale1"
    )
    val pulseScale2 by transition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, delayMillis = 300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale2"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = stringResource(id = R.string.choose_device),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            },
            navigationIcon = {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            },
            actions = {
                IconButton(onClick = onScanQrClick) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = stringResource(id = R.string.scan_qr),
                        tint = DesignTokens.ColorPrimary
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = DesignTokens.Spacing16, vertical = DesignTokens.Spacing12)
        ) {
            Text(
                text = stringResource(id = R.string.looking_for_devices),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(DesignTokens.Spacing16))

            // Animated Ultramarine Radar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .scale(pulseScale1)
                        .background(
                            DesignTokens.ColorPrimary.copy(alpha = 0.12f),
                            CircleShape
                        )
                )
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .scale(pulseScale2)
                        .background(
                            DesignTokens.ColorPrimary.copy(alpha = 0.22f),
                            CircleShape
                        )
                )
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            DesignTokens.ColorPrimary,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.5.dp,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing12))

            // Discovered devices list
            if (discoveredDevices.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(DesignTokens.Spacing24)
                    ) {
                        Text(
                            text = stringResource(id = R.string.no_devices_found),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(DesignTokens.Spacing12))
                        Text(
                            text = "Make sure the recipient device has opened Receive mode and is nearby.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(DesignTokens.Spacing24))
                        OutlinedButton(
                            onClick = onScanQrClick,
                            shape = RoundedCornerShape(DesignTokens.RadiusMd),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, DesignTokens.ColorPrimary)
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                tint = DesignTokens.ColorPrimary
                            )
                            Spacer(modifier = Modifier.width(DesignTokens.Spacing12))
                            Text(
                                text = stringResource(id = R.string.scan_qr_prompt),
                                color = DesignTokens.ColorPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(DesignTokens.Spacing12)
                ) {
                    items(discoveredDevices, key = { it.endpointId }) { device ->
                        DiscoveredDeviceCard(
                            device = device,
                            onClick = { onDeviceSelected(device) }
                        )
                    }
                }
            }
        }

        // Bottom QR Fallback Button in full pill shape
        Surface(
            shadowElevation = 2.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = DesignTokens.Spacing16, vertical = DesignTokens.Spacing12),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onScanQrClick,
                    shape = RoundedCornerShape(DesignTokens.RadiusMd),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = DesignTokens.ColorPrimary
                    )
                    Spacer(modifier = Modifier.width(DesignTokens.Spacing12))
                    Text(
                        text = stringResource(id = R.string.scan_qr),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun DiscoveredDeviceCard(
    device: DiscoveredDevice,
    onClick: () -> Unit
) {
    val isConnecting = device.connectionState == DeviceConnectionState.CONNECTING ||
            device.connectionState == DeviceConnectionState.AUTHENTICATING

    Surface(
        shape = RoundedCornerShape(DesignTokens.RadiusXl),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DesignTokens.RadiusXl))
            .border(
                1.dp,
                if (isConnecting) DesignTokens.ColorPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                RoundedCornerShape(DesignTokens.RadiusXl)
            )
            .clickable(enabled = !isConnecting) { onClick() }
            .testTag("device_card_${device.endpointId}")
    ) {
        Row(
            modifier = Modifier.padding(DesignTokens.Spacing16),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AvatarIcon(avatarId = device.avatarId, size = 48.dp)

            Spacer(modifier = Modifier.width(DesignTokens.Spacing16))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = device.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = when (device.connectionState) {
                        DeviceConnectionState.CONNECTING -> "Connecting…"
                        DeviceConnectionState.AUTHENTICATING -> "Verifying PIN…"
                        DeviceConnectionState.CONNECTED -> "Connected"
                        DeviceConnectionState.REJECTED -> "Declined"
                        DeviceConnectionState.FAILED -> "Failed"
                        else -> "Tap to send files"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isConnecting) DesignTokens.ColorPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (isConnecting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.5.dp,
                    color = DesignTokens.ColorPrimary
                )
            } else {
                Box(
                    modifier = Modifier
                        .background(
                            DesignTokens.ColorBg3,
                            RoundedCornerShape(DesignTokens.RadiusMd)
                        )
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = "Connect",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = DesignTokens.ColorPrimary
                    )
                }
            }
        }
    }
}
