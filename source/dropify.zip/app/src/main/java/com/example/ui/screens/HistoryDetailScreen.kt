package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.TransferEntity
import com.example.data.model.FileMetadata
import com.example.ui.theme.DesignTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryDetailScreen(
    transfer: TransferEntity?,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "Transfer Details",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            },
            navigationIcon = {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("history_detail_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        if (transfer == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(DesignTokens.Spacing24),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Transfer record not found",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            val isSent = transfer.isSent()
            val dateStr = transfer.getFormattedDetailedDateTime()
            val totalFormatted = transfer.getFormattedTotalBytes()
            val speedFormatted = transfer.getFormattedSpeed()

            // Prepare list of FileMetadata items
            val filesList: List<FileMetadata> = if (transfer.files.isNotEmpty()) {
                transfer.files
            } else {
                transfer.fileNames.split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                    .map { FileMetadata(name = it, size = 0L, mimeType = "application/octet-stream") }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = DesignTokens.Spacing16),
                verticalArrangement = Arrangement.spacedBy(DesignTokens.Spacing16)
            ) {
                item {
                    Spacer(modifier = Modifier.height(DesignTokens.Spacing4))

                    // Transfer Summary Card
                    Surface(
                        shape = RoundedCornerShape(DesignTokens.RadiusXl),
                        color = MaterialTheme.colorScheme.surface,
                        shadowElevation = 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(DesignTokens.RadiusXl))
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                RoundedCornerShape(DesignTokens.RadiusXl)
                            )
                    ) {
                        Column(modifier = Modifier.padding(DesignTokens.Spacing16)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(52.dp)
                                        .background(
                                            if (isSent) DesignTokens.ColorBg3 else Color(0xFF2C2C34),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isSent) Icons.Default.FileUpload else Icons.Default.FileDownload,
                                        contentDescription = null,
                                        tint = if (isSent) DesignTokens.ColorPrimary else Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(DesignTokens.Spacing12))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isSent) "Sent to" else "Received from",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = transfer.deviceName,
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                // Status pill
                                Box(
                                    modifier = Modifier
                                        .background(
                                            when (transfer.status) {
                                                "COMPLETED" -> Color(0xFF00C48C).copy(alpha = 0.15f)
                                                "CANCELLED" -> MaterialTheme.colorScheme.surfaceVariant
                                                else -> Color(0xFFFF4861).copy(alpha = 0.15f)
                                            },
                                            RoundedCornerShape(DesignTokens.RadiusMd)
                                        )
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = when (transfer.status) {
                                            "COMPLETED" -> "Success"
                                            "CANCELLED" -> "Cancelled"
                                            else -> "Failed"
                                        },
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = when (transfer.status) {
                                            "COMPLETED" -> Color(0xFF00C48C)
                                            "CANCELLED" -> MaterialTheme.colorScheme.onSurfaceVariant
                                            else -> Color(0xFFFF4861)
                                        }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(DesignTokens.Spacing16))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            Spacer(modifier = Modifier.height(DesignTokens.Spacing12))

                            DetailRow(label = "Date & Time", value = dateStr)
                            DetailRow(label = "Total Size", value = totalFormatted)
                            DetailRow(label = "Files Count", value = "${transfer.fileCount} file${if (transfer.fileCount != 1) "s" else ""}")
                            DetailRow(label = "Status", value = transfer.status)
                            if (speedFormatted.isNotEmpty()) {
                                DetailRow(label = "Speed", value = speedFormatted)
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "Transferred Files (${filesList.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                items(filesList) { file ->
                    FileMetadataItemCard(file = file)
                }

                item {
                    Spacer(modifier = Modifier.height(DesignTokens.Spacing24))
                }
            }
        }
    }
}

@Composable
private fun FileMetadataItemCard(file: FileMetadata) {
    val icon = getFileIcon(file.mimeType)
    val ext = file.getFileExtension()

    Surface(
        shape = RoundedCornerShape(DesignTokens.RadiusXl),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DesignTokens.RadiusXl))
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                RoundedCornerShape(DesignTokens.RadiusXl)
            )
    ) {
        Row(
            modifier = Modifier.padding(DesignTokens.Spacing16),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(DesignTokens.ColorBg3, RoundedCornerShape(DesignTokens.RadiusMd)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = DesignTokens.ColorPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(DesignTokens.Spacing12))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = file.name,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (file.size > 0) {
                        Text(
                            text = file.getFormattedSize(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = " • ",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = file.getCategoryName(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Box(
                modifier = Modifier
                    .background(
                        DesignTokens.ColorPrimary.copy(alpha = 0.1f),
                        RoundedCornerShape(DesignTokens.RadiusMd)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = ext,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                    color = DesignTokens.ColorPrimary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

private fun getFileIcon(mimeType: String): ImageVector {
    return when {
        mimeType.startsWith("image/") -> Icons.Default.Image
        mimeType.startsWith("video/") -> Icons.Default.Videocam
        mimeType.startsWith("audio/") -> Icons.Default.Audiotrack
        else -> Icons.Default.Description
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
