package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.db.TransferEntity
import com.example.ui.components.AvatarIcon
import com.example.ui.theme.DesignTokens

@Composable
fun HomeScreen(
    deviceName: String,
    avatarId: Int,
    recentTransfers: List<TransferEntity> = emptyList(),
    onSendClick: () -> Unit,
    onReceiveClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onQuickCategoryClick: (String) -> Unit,
    onScanQrClick: () -> Unit = {},
    onShowQrClick: () -> Unit = {},
    onProfileClick: () -> Unit = {},
    onTransferClick: (TransferEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulseGlow")
    val glowScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowScale"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = DesignTokens.Spacing16, vertical = DesignTokens.Spacing12)
        ) {
            // 1. Hero Device Identity & Quick Status Card
            Surface(
                shape = RoundedCornerShape(DesignTokens.RadiusXl),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(DesignTokens.RadiusXl))
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                        RoundedCornerShape(DesignTokens.RadiusXl)
                    )
                    .testTag("home_profile_card")
            ) {
                Column(modifier = Modifier.padding(DesignTokens.Spacing16)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onProfileClick() },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AvatarIcon(avatarId = avatarId, size = 48.dp)
                        Spacer(modifier = Modifier.width(DesignTokens.Spacing12))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .scale(glowScale)
                                        .clip(CircleShape)
                                        .background(Color(0xFF00C48C))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Ready to share",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF00C48C)
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = deviceName,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(DesignTokens.ColorBg3, CircleShape)
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Profile",
                                tint = DesignTokens.ColorPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(DesignTokens.Spacing12))

                    // Quick QR pairing shortcuts bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(DesignTokens.Spacing8)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(DesignTokens.RadiusMd),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(DesignTokens.RadiusMd))
                                .clickable { onScanQrClick() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = null,
                                    tint = DesignTokens.ColorPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Scan QR",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(DesignTokens.RadiusMd),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(DesignTokens.RadiusMd))
                                .clickable { onShowQrClick() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCode,
                                    contentDescription = null,
                                    tint = DesignTokens.ColorPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "My QR Code",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing16))

            // 2. Primary Action Launchpad (Send & Receive)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(DesignTokens.Spacing12)
            ) {
                // Send Card: Vibrant Electric Ultramarine Gradient (#4D43FE -> #7985FF)
                TransferActionCard(
                    title = stringResource(id = R.string.send),
                    subtitle = "Instant beam",
                    badge = "Fast P2P",
                    icon = Icons.Rounded.FileUpload,
                    gradientColors = listOf(DesignTokens.ColorPrimary, DesignTokens.RampPrimary400),
                    testTag = "send_action_button",
                    onClick = onSendClick,
                    modifier = Modifier.weight(1f)
                )

                // Receive Card: Sleek Obsidian Contrast Card
                TransferActionCard(
                    title = stringResource(id = R.string.receive),
                    subtitle = "Visible nearby",
                    badge = "Incoming",
                    icon = Icons.Rounded.FileDownload,
                    gradientColors = listOf(DesignTokens.SurfaceRaisedBg, Color(0xFF2B2B38)),
                    testTag = "receive_action_button",
                    onClick = onReceiveClick,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing24))

            // 3. Quick Access Category Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Quick Select by Type",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "Direct Picker",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = DesignTokens.ColorPrimary
                )
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing12))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                QuickCategoryItem(
                    label = stringResource(id = R.string.photos),
                    icon = Icons.Default.Image,
                    iconTint = DesignTokens.ColorPrimary,
                    containerColor = DesignTokens.ColorBg3,
                    onClick = { onQuickCategoryClick("image/*") }
                )
                QuickCategoryItem(
                    label = stringResource(id = R.string.videos),
                    icon = Icons.Default.Videocam,
                    iconTint = Color(0xFFFF4861),
                    containerColor = Color(0xFFFFECEF),
                    onClick = { onQuickCategoryClick("video/*") }
                )
                QuickCategoryItem(
                    label = stringResource(id = R.string.audio),
                    icon = Icons.Default.Audiotrack,
                    iconTint = Color(0xFFFF9F1C),
                    containerColor = Color(0xFFFFF4E5),
                    onClick = { onQuickCategoryClick("audio/*") }
                )
                QuickCategoryItem(
                    label = stringResource(id = R.string.documents),
                    icon = Icons.Default.Description,
                    iconTint = Color(0xFF00C48C),
                    containerColor = Color(0xFFE6F9F3),
                    onClick = { onQuickCategoryClick("application/*") }
                )
                QuickCategoryItem(
                    label = "Files",
                    icon = Icons.Default.Folder,
                    iconTint = DesignTokens.RampPrimary800,
                    containerColor = DesignTokens.RampPrimary50,
                    onClick = { onQuickCategoryClick("*/*") }
                )
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing24))

            // 4. Recent Activity Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Activity",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.weight(1f))
                TextButton(onClick = onHistoryClick) {
                    Text(
                        text = "View All →",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = DesignTokens.ColorPrimary
                    )
                }
            }

            if (recentTransfers.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(DesignTokens.Spacing8)) {
                    recentTransfers.forEach { item ->
                        RecentTransferItem(
                            item = item,
                            onClick = { onTransferClick(item) }
                        )
                    }
                }
            } else {
                // Friendly Quick Tip Banner
                Surface(
                    shape = RoundedCornerShape(DesignTokens.RadiusXl),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(DesignTokens.RadiusXl))
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                            RoundedCornerShape(DesignTokens.RadiusXl)
                        )
                        .clickable { onHistoryClick() }
                ) {
                    Row(
                        modifier = Modifier.padding(DesignTokens.Spacing16),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .background(DesignTokens.ColorBg3, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = DesignTokens.ColorPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(DesignTokens.Spacing12))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "No recent transfers",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Tap Send or Receive above to beam files wirelessly.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing20))

            // 5. Security & Technology Feature Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(DesignTokens.Spacing8)
            ) {
                FeatureBadge(
                    icon = Icons.Default.Wifi,
                    label = "Wi-Fi Direct",
                    modifier = Modifier.weight(1f)
                )
                FeatureBadge(
                    icon = Icons.Default.Bolt,
                    label = "High Speed",
                    modifier = Modifier.weight(1f)
                )
                FeatureBadge(
                    icon = Icons.Default.Lock,
                    label = "P2P Secure",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing24))
        }
    }
}

@Composable
private fun TransferActionCard(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    gradientColors: List<Color>,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val animatedScale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1.0f,
        animationSpec = spring(stiffness = 500f),
        label = "actionPressScale"
    )

    Card(
        shape = RoundedCornerShape(DesignTokens.RadiusXl),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .graphicsLayer {
                scaleX = animatedScale
                scaleY = animatedScale
            }
            .clip(RoundedCornerShape(DesignTokens.RadiusXl))
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(colors = gradientColors))
                .padding(DesignTokens.Spacing16)
        ) {
            Column(
                modifier = Modifier.height(138.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color.White.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.22f), RoundedCornerShape(DesignTokens.RadiusMd))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = badge,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White,
                            fontSize = 11.sp
                        )
                    }
                }

                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold
                        ),
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.88f)
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickCategoryItem(
    label: String,
    icon: ImageVector,
    iconTint: Color,
    containerColor: Color,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val animatedScale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1.0f,
        animationSpec = spring(stiffness = 600f),
        label = "categoryPressScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .graphicsLayer {
                scaleX = animatedScale
                scaleY = animatedScale
            }
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .background(containerColor, RoundedCornerShape(DesignTokens.RadiusLg))
                .border(
                    1.dp,
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                    RoundedCornerShape(DesignTokens.RadiusLg)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = iconTint,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1
        )
    }
}

@Composable
private fun RecentTransferItem(
    item: TransferEntity,
    onClick: () -> Unit
) {
    val isSent = item.isSent()

    Surface(
        shape = RoundedCornerShape(DesignTokens.RadiusXl),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DesignTokens.RadiusXl))
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                RoundedCornerShape(DesignTokens.RadiusXl)
            )
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = DesignTokens.Spacing16, vertical = DesignTokens.Spacing12),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        if (isSent) DesignTokens.ColorBg3 else Color(0xFF2C2C34),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isSent) Icons.Rounded.FileUpload else Icons.Rounded.FileDownload,
                    contentDescription = null,
                    tint = if (isSent) DesignTokens.ColorPrimary else Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(DesignTokens.Spacing12))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${if (isSent) "To" else "From"} ${item.deviceName}",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${item.fileCount} file${if (item.fileCount != 1) "s" else ""} • ${item.getFormattedTotalBytes()} • ${item.getFormattedTime()}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Box(
                modifier = Modifier
                    .background(
                        when (item.status) {
                            "COMPLETED" -> Color(0xFF00C48C).copy(alpha = 0.15f)
                            "CANCELLED" -> MaterialTheme.colorScheme.surfaceVariant
                            else -> Color(0xFFFF4861).copy(alpha = 0.15f)
                        },
                        RoundedCornerShape(DesignTokens.RadiusMd)
                    )
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = when (item.status) {
                        "COMPLETED" -> "Success"
                        "CANCELLED" -> "Cancelled"
                        else -> "Failed"
                    },
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = when (item.status) {
                        "COMPLETED" -> Color(0xFF00C48C)
                        "CANCELLED" -> MaterialTheme.colorScheme.onSurfaceVariant
                        else -> Color(0xFFFF4861)
                    }
                )
            }
        }
    }
}

@Composable
private fun FeatureBadge(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(DesignTokens.RadiusMd),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = DesignTokens.ColorPrimary,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
        }
    }
}
