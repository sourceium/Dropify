package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.AvatarCatalog
import com.example.ui.components.AvatarIcon
import com.example.ui.theme.DesignTokens

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ProfileSetupScreen(
    initialDeviceName: String,
    initialAvatarId: Int,
    isEditMode: Boolean = false,
    onBackClick: (() -> Unit)? = null,
    onSaveProfile: (String, Int) -> Unit
) {
    var deviceName by remember(initialDeviceName) { mutableStateOf(initialDeviceName) }
    var selectedAvatarId by remember(initialAvatarId) { mutableIntStateOf(initialAvatarId) }

    if (isEditMode && onBackClick != null) {
        BackHandler {
            onBackClick()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (isEditMode) {
            TopAppBar(
                title = {
                    Text(
                        text = "Edit Profile",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    if (onBackClick != null) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier.testTag("edit_profile_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(if (!isEditMode) Modifier.statusBarsPadding() else Modifier)
                .padding(horizontal = DesignTokens.SpacingS4)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(if (isEditMode) DesignTokens.SpacingS3 else DesignTokens.SpacingS5))

            if (!isEditMode) {
                Text(
                    text = stringResource(id = R.string.profile_setup_title),
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 26.sp
                    ),
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(DesignTokens.SpacingS1))
            }

            Text(
                text = if (isEditMode) "Update your device name and avatar anytime." else stringResource(id = R.string.profile_setup_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(DesignTokens.SpacingS5))

            // Large Preview Avatar with soft ambient border
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 4.dp,
                modifier = Modifier.padding(DesignTokens.SpacingS0)
            ) {
                Box(modifier = Modifier.padding(DesignTokens.SpacingS1)) {
                    AvatarIcon(
                        avatarId = selectedAvatarId,
                        size = 96.dp
                    )
                }
            }

            Spacer(modifier = Modifier.height(DesignTokens.SpacingS4))

            // Device Name Input
            OutlinedTextField(
                value = deviceName,
                onValueChange = { deviceName = it },
                label = { Text(stringResource(id = R.string.device_name_label)) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("device_name_input"),
                shape = RoundedCornerShape(DesignTokens.RadiusR2),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = DesignTokens.BrandPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )

            Spacer(modifier = Modifier.height(DesignTokens.SpacingS4))

            Text(
                text = stringResource(id = R.string.choose_avatar),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(DesignTokens.SpacingS2))

            // FlowRow of 12 distinct avatars
            Surface(
                shape = RoundedCornerShape(DesignTokens.RadiusR3),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(DesignTokens.RadiusR3))
                    .padding(DesignTokens.SpacingS3)
            ) {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    maxItemsInEachRow = 4
                ) {
                    AvatarCatalog.avatars.forEach { avatarDef ->
                        AvatarIcon(
                            avatarId = avatarDef.id,
                            size = 54.dp,
                            isSelected = selectedAvatarId == avatarDef.id,
                            onClick = { selectedAvatarId = avatarDef.id }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(DesignTokens.SpacingS6))

            // Primary Action Pill Button
            Button(
                onClick = {
                    val finalName = deviceName.trim().ifBlank { initialDeviceName }
                    onSaveProfile(finalName, selectedAvatarId)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("save_profile_button"),
                shape = RoundedCornerShape(DesignTokens.RadiusR5),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DesignTokens.ActionPrimary,
                    contentColor = DesignTokens.ActionOnPrimary
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
            ) {
                Text(
                    text = if (isEditMode) stringResource(id = R.string.save) else stringResource(id = R.string.continue_action),
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.height(DesignTokens.SpacingS4))
        }
    }
}
