package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.AvatarIcon
import com.example.ui.components.QrCodeHelper
import com.example.ui.theme.DesignTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrDisplayScreen(
    deviceName: String,
    avatarId: Int,
    generateQrPayload: () -> String,
    onBackClick: () -> Unit
) {
    var qrBitmap by remember { mutableStateOf<ImageBitmap?>(null) }
    var payloadString by remember { mutableStateOf("") }

    fun refreshQr() {
        val payload = generateQrPayload()
        payloadString = payload
        qrBitmap = QrCodeHelper.generateQrBitmap(payload, 600)
    }

    LaunchedEffect(Unit) {
        refreshQr()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = stringResource(id = R.string.show_qr),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            },
            navigationIcon = {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            },
            actions = {
                IconButton(onClick = { refreshQr() }) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh QR",
                        tint = DesignTokens.BrandPrimary
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(DesignTokens.SpacingS4),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(DesignTokens.SpacingS2))

            AvatarIcon(avatarId = avatarId, size = 68.dp)
            Spacer(modifier = Modifier.height(DesignTokens.SpacingS2))

            Text(
                text = deviceName,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = "Scan with sender phone to instantly pair",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(DesignTokens.SpacingS5))

            // QR Code Container with subtle ultramarine border
            Surface(
                shape = RoundedCornerShape(DesignTokens.RadiusR3),
                color = Color.White,
                shadowElevation = 4.dp,
                modifier = Modifier
                    .size(280.dp)
                    .border(2.dp, DesignTokens.BrandPrimary.copy(alpha = 0.2f), RoundedCornerShape(DesignTokens.RadiusR3))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(DesignTokens.SpacingS3),
                    contentAlignment = Alignment.Center
                ) {
                    val bmp = qrBitmap
                    if (bmp != null) {
                        Image(
                            bitmap = bmp,
                            contentDescription = "Pairing QR Code",
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text(
                            text = "Generating QR Code…",
                            color = Color.DarkGray,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(DesignTokens.SpacingS4))

            Box(
                modifier = Modifier
                    .background(DesignTokens.BackgroundBg3, RoundedCornerShape(DesignTokens.RadiusR5))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Valid for 5 minutes • E2E Encrypted",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = DesignTokens.BrandPrimary
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            OutlinedButton(
                onClick = { refreshQr() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(DesignTokens.RadiusR5),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, DesignTokens.BrandPrimary)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    tint = DesignTokens.BrandPrimary
                )
                Spacer(modifier = Modifier.width(DesignTokens.SpacingS1))
                Text(
                    text = "Refresh QR Code",
                    color = DesignTokens.BrandPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(DesignTokens.SpacingS2))
        }
    }
}
