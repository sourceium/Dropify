package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.AvatarIcon
import com.example.ui.theme.DesignTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiveWaitingScreen(
    deviceName: String,
    avatarId: Int,
    onStartAdvertising: () -> Unit,
    onStopAdvertising: () -> Unit,
    onShowQrClick: () -> Unit,
    onBackClick: () -> Unit
) {
    DisposableEffect(Unit) {
        onStartAdvertising()
        onDispose {
            onStopAdvertising()
        }
    }

    val transition = rememberInfiniteTransition(label = "beacon")
    
    // Multi-stage radar pulse
    val wave1Scale by transition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.45f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave1Scale"
    )
    val wave1Alpha by transition.animateFloat(
        initialValue = 0.40f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave1Alpha"
    )

    val wave2Scale by transition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, delayMillis = 400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave2Scale"
    )
    val wave2Alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, delayMillis = 400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave2Alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = stringResource(id = R.string.receive),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            },
            navigationIcon = {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            },
            actions = {
                IconButton(onClick = onShowQrClick) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = stringResource(id = R.string.show_qr),
                        tint = DesignTokens.ColorPrimary
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(DesignTokens.Spacing20),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Animated Ultramarine Radar Beacon Wave
            Box(
                modifier = Modifier.size(240.dp),
                contentAlignment = Alignment.Center
            ) {
                // Expanding wave 1
                Box(
                    modifier = Modifier
                        .size(230.dp)
                        .scale(wave1Scale)
                        .background(
                            DesignTokens.ColorPrimary.copy(alpha = wave1Alpha),
                            CircleShape
                        )
                )

                // Expanding wave 2
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .scale(wave2Scale)
                        .background(
                            DesignTokens.RampPrimary400.copy(alpha = wave2Alpha),
                            CircleShape
                        )
                )

                // Soft ambient glow background
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .background(DesignTokens.ColorBg3, CircleShape)
                )

                Surface(
                    shape = CircleShape,
                    shadowElevation = 6.dp,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.size(96.dp)
                ) {
                    Box(modifier = Modifier.padding(6.dp)) {
                        AvatarIcon(
                            avatarId = avatarId,
                            size = 84.dp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing24))

            Text(
                text = stringResource(id = R.string.ready_to_receive),
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.ExtraBold
                ),
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(DesignTokens.Spacing12))

            Box(
                modifier = Modifier
                    .background(
                        DesignTokens.ColorBg3,
                        RoundedCornerShape(DesignTokens.RadiusMd)
                    )
                    .padding(horizontal = 18.dp, vertical = 7.dp)
            ) {
                Text(
                    text = "Visible as \"$deviceName\"",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = DesignTokens.ColorPrimary
                )
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing16))

            Text(
                text = "Nearby senders can detect this device and transfer files directly over peer-to-peer Wi-Fi & Bluetooth.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = DesignTokens.Spacing24)
            )

            Spacer(modifier = Modifier.height(DesignTokens.Spacing32))

            OutlinedButton(
                onClick = onShowQrClick,
                shape = RoundedCornerShape(DesignTokens.RadiusMd),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, DesignTokens.ColorPrimary),
                modifier = Modifier.testTag("show_qr_button")
            ) {
                Icon(
                    imageVector = Icons.Default.QrCode,
                    contentDescription = null,
                    tint = DesignTokens.ColorPrimary
                )
                Spacer(modifier = Modifier.width(DesignTokens.Spacing12))
                Text(
                    text = stringResource(id = R.string.show_qr),
                    color = DesignTokens.ColorPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Bottom Stop Receiving Action Bar
        Surface(
            shadowElevation = 2.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = DesignTokens.Spacing16, vertical = DesignTokens.Spacing12)
            ) {
                Button(
                    onClick = {
                        onStopAdvertising()
                        onBackClick()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("stop_receiving_button"),
                    shape = RoundedCornerShape(DesignTokens.RadiusMd),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DesignTokens.SurfaceRaisedBg,
                        contentColor = DesignTokens.SurfaceRaisedFg
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                ) {
                    Text(
                        text = stringResource(id = R.string.stop_receiving),
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}
