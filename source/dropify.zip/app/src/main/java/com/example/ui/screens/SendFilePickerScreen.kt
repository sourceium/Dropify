package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.FileItem
import com.example.ui.theme.DesignTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SendFilePickerScreen(
    selectedFiles: List<FileItem>,
    onFilesSelected: (List<FileItem>) -> Unit,
    onNavigateToReview: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current

    fun queryFileItem(uri: Uri): FileItem {
        var name = "file_${System.currentTimeMillis()}"
        var size = 0L
        val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) name = cursor.getString(nameIndex) ?: name
                    if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (_: Exception) {}

        return FileItem(uri = uri, name = name, size = size, mimeType = mime)
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 100)
    ) { uris ->
        if (uris.isNotEmpty()) {
            val items = uris.map { queryFileItem(it) }
            onFilesSelected(items)
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            val items = uris.map { queryFileItem(it) }
            onFilesSelected(items)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "Select Files to Beam",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            },
            navigationIcon = {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = DesignTokens.Spacing16, vertical = DesignTokens.Spacing12),
            verticalArrangement = Arrangement.spacedBy(DesignTokens.Spacing12)
        ) {
            Text(
                text = "Choose category to browse files",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            PickerCategoryRow(
                title = stringResource(id = R.string.photos),
                subtitle = "Photos, Screenshots, Camera roll",
                badge = "Zero Loss",
                icon = Icons.Default.Image,
                iconTint = DesignTokens.ColorPrimary,
                containerColor = DesignTokens.ColorBg3,
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                }
            )

            PickerCategoryRow(
                title = stringResource(id = R.string.videos),
                subtitle = "4K Movies, Clips, Recordings",
                badge = "Full Res",
                icon = Icons.Default.Videocam,
                iconTint = Color(0xFFFF4861),
                containerColor = Color(0xFFFFECEF),
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                }
            )

            PickerCategoryRow(
                title = stringResource(id = R.string.audio),
                subtitle = "Music albums, Voice recordings, Audiobooks",
                badge = "Lossless",
                icon = Icons.Default.Audiotrack,
                iconTint = Color(0xFFFF9F1C),
                containerColor = Color(0xFFFFF4E5),
                onClick = {
                    documentPickerLauncher.launch(arrayOf("audio/*"))
                }
            )

            PickerCategoryRow(
                title = stringResource(id = R.string.documents),
                subtitle = "PDFs, Word docs, Spreadsheets, Slides",
                badge = "Original",
                icon = Icons.Default.Description,
                iconTint = Color(0xFF00C48C),
                containerColor = Color(0xFFE6F9F3),
                onClick = {
                    documentPickerLauncher.launch(arrayOf(
                        "application/pdf",
                        "application/msword",
                        "application/vnd.openxmlformats-officedocument.*",
                        "text/plain"
                    ))
                }
            )

            PickerCategoryRow(
                title = stringResource(id = R.string.browse_files),
                subtitle = "Storage explorer, Downloads, Archives, APKs",
                badge = "All Files",
                icon = Icons.Default.Folder,
                iconTint = DesignTokens.RampPrimary800,
                containerColor = DesignTokens.RampPrimary50,
                onClick = {
                    documentPickerLauncher.launch(arrayOf("*/*"))
                }
            )

            Spacer(modifier = Modifier.height(DesignTokens.Spacing16))
        }

        // Bottom Staged Summary & Continue Action Bar
        Surface(
            shadowElevation = 4.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = DesignTokens.Spacing16, vertical = DesignTokens.Spacing12),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${selectedFiles.size} file${if (selectedFiles.size != 1) "s" else ""} chosen",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    val total = selectedFiles.sumOf { it.size }
                    Text(
                        text = if (total > 0) "Total: ${FileItem(Uri.EMPTY, "", total, "").getFormattedSize()}" else "Pick files to start beam",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (total > 0) DesignTokens.ColorPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (total > 0) FontWeight.Bold else FontWeight.Normal
                    )
                }

                Button(
                    onClick = onNavigateToReview,
                    enabled = selectedFiles.isNotEmpty(),
                    shape = RoundedCornerShape(DesignTokens.RadiusMd),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DesignTokens.ColorPrimary,
                        contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("continue_to_review_button")
                ) {
                    Text(
                        text = "Review (${selectedFiles.size})",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun PickerCategoryRow(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    iconTint: Color,
    containerColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(DesignTokens.RadiusXl),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DesignTokens.RadiusXl))
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                RoundedCornerShape(DesignTokens.RadiusXl)
            )
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(DesignTokens.Spacing16),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(containerColor, RoundedCornerShape(DesignTokens.RadiusLg)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(DesignTokens.Spacing16))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(DesignTokens.RadiusMd)
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badge,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
