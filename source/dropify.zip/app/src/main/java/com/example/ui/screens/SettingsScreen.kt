package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.preferences.UserPreferences
import com.example.ui.components.AppLogo
import com.example.ui.components.AvatarIcon
import com.example.ui.theme.DesignTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    userPreferences: UserPreferences,
    onEditProfileClick: () -> Unit,
    onThemeSelected: (String) -> Unit,
    onDeviceVisibilityToggle: (Boolean) -> Unit,
    onClearHistoryClick: () -> Unit,
    onBackClick: () -> Unit
) {
    var showThemeDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showClearHistoryConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = stringResource(id = R.string.settings),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            },
            navigationIcon = {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = DesignTokens.Spacing16, vertical = DesignTokens.Spacing12),
            verticalArrangement = Arrangement.spacedBy(DesignTokens.Spacing16)
        ) {
            // Section: Profile
            SettingsSectionHeader(stringResource(id = R.string.profile))
            Surface(
                shape = RoundedCornerShape(DesignTokens.RadiusXl),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(DesignTokens.RadiusXl))
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                        RoundedCornerShape(DesignTokens.RadiusXl)
                    )
                    .clickable { onEditProfileClick() }
            ) {
                Row(
                    modifier = Modifier.padding(DesignTokens.Spacing16),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AvatarIcon(avatarId = userPreferences.avatarId, size = 48.dp)
                    Spacer(modifier = Modifier.width(DesignTokens.Spacing16))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = userPreferences.deviceName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Tap to customize name and avatar",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        tint = DesignTokens.ColorPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Section: Appearance
            SettingsSectionHeader(stringResource(id = R.string.appearance))
            Surface(
                shape = RoundedCornerShape(DesignTokens.RadiusXl),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(DesignTokens.RadiusXl))
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                        RoundedCornerShape(DesignTokens.RadiusXl)
                    )
            ) {
                SettingsClickableItem(
                    title = "App Theme",
                    subtitle = when (userPreferences.themeSetting) {
                        "light" -> stringResource(id = R.string.theme_light)
                        "dark" -> stringResource(id = R.string.theme_dark)
                        else -> stringResource(id = R.string.theme_system)
                    },
                    icon = Icons.Default.Palette,
                    onClick = { showThemeDialog = true }
                )
            }

            // Section: Receiving & Privacy
            SettingsSectionHeader("Sharing & Storage")
            Surface(
                shape = RoundedCornerShape(DesignTokens.RadiusXl),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(DesignTokens.RadiusXl))
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                        RoundedCornerShape(DesignTokens.RadiusXl)
                    )
            ) {
                Column {
                    SettingsSwitchItem(
                        title = stringResource(id = R.string.device_visibility),
                        subtitle = "Allow nearby senders to discover this phone",
                        icon = Icons.Default.Visibility,
                        checked = userPreferences.isDeviceVisible,
                        onCheckedChange = onDeviceVisibilityToggle
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    SettingsClickableItem(
                        title = stringResource(id = R.string.receive_folder),
                        subtitle = userPreferences.receiveFolder,
                        icon = Icons.Default.Folder,
                        onClick = {}
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    SettingsClickableItem(
                        title = stringResource(id = R.string.clear_history),
                        subtitle = "Clear session log (files stay safe on device)",
                        icon = Icons.Default.DeleteSweep,
                        onClick = { showClearHistoryConfirm = true }
                    )
                }
            }

            // Section: About
            SettingsSectionHeader(stringResource(id = R.string.about))
            Surface(
                shape = RoundedCornerShape(DesignTokens.RadiusXl),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(DesignTokens.RadiusXl))
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                        RoundedCornerShape(DesignTokens.RadiusXl)
                    )
            ) {
                Column {
                    SettingsClickableItem(
                        title = "About Dropify",
                        subtitle = "Version 1.0.0 • Peer-to-Peer Nearby Sharing",
                        icon = Icons.Default.Info,
                        onClick = { showAboutDialog = true }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    SettingsClickableItem(
                        title = stringResource(id = R.string.privacy_policy),
                        subtitle = "100% Offline P2P • No cloud storage or tracking",
                        icon = Icons.Default.Security,
                        onClick = { showPrivacyDialog = true }
                    )
                }
            }

            Spacer(modifier = Modifier.height(DesignTokens.Spacing24))
        }
    }

    // Theme Picker Dialog
    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("Select Theme", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    listOf("system" to "System Default", "light" to "Light", "dark" to "Dark").forEach { (key, label) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onThemeSelected(key)
                                    showThemeDialog = false
                                }
                                .padding(vertical = 10.dp)
                        ) {
                            RadioButton(
                                selected = userPreferences.themeSetting == key,
                                onClick = {
                                    onThemeSelected(key)
                                    showThemeDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = DesignTokens.ColorPrimary)
                            )
                            Spacer(modifier = Modifier.width(DesignTokens.Spacing12))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (userPreferences.themeSetting == key) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            icon = {
                AppLogo(size = 52.dp)
            },
            title = { Text("About Dropify", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        text = "Dropify — Fast, private, and secure wireless file sharing between nearby devices without mobile data.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(DesignTokens.Spacing12))
                    Text(
                        text = "• Peer-to-peer Wi-Fi Direct and Bluetooth\n• Zero file compression\n• End-to-end encrypted transfers\n• No cloud upload required",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(DesignTokens.Spacing12))
                    Text(
                        text = "Version 1.0.0",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text("OK", fontWeight = FontWeight.Bold, color = DesignTokens.ColorPrimary)
                }
            }
        )
    }

    // Clear History Dialog
    if (showClearHistoryConfirm) {
        AlertDialog(
            onDismissRequest = { showClearHistoryConfirm = false },
            title = { Text(stringResource(id = R.string.clear_history), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(id = R.string.clear_history_confirm)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearHistoryClick()
                        showClearHistoryConfirm = false
                    }
                ) {
                    Text(
                        stringResource(id = R.string.clear),
                        color = Color(0xFFFF4861),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryConfirm = false }) {
                    Text(stringResource(id = R.string.cancel))
                }
            }
        )
    }

    // Privacy Policy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = DesignTokens.ColorPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(DesignTokens.Spacing8))
                    Text(stringResource(id = R.string.privacy_policy), fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(DesignTokens.Spacing8)
                ) {
                    Text(
                        text = "Dropify uses a 100% peer-to-peer (P2P) local architecture. Your files travel directly between nearby devices over Wi-Fi Direct or Bluetooth.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(DesignTokens.Spacing4))
                    Text(
                        text = "• Zero Cloud: Files never upload to any remote server or third-party cloud.\n" +
                                "• Zero Tracking: No analytics, tracking SDKs, or advertisements.\n" +
                                "• Permissions: Wi-Fi, Bluetooth & Camera (QR pairing only).\n" +
                                "• Package Name: com.HaldarAi.Dropify\n" +
                                "• Developer: Subhojit Haldar\n" +
                                "• Grievance Officer Email: business.tizongaming@gmail.com\n" +
                                "• Support Phone: +91 8637856826\n" +
                                "• Location: West Bengal, India",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text("OK", fontWeight = FontWeight.Bold, color = DesignTokens.ColorPrimary)
                }
            }
        )
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = DesignTokens.ColorPrimary,
        modifier = Modifier.padding(start = 4.dp)
    )
}

@Composable
private fun SettingsClickableItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(DesignTokens.Spacing16),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = DesignTokens.ColorPrimary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(DesignTokens.Spacing16))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun SettingsSwitchItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(DesignTokens.Spacing16),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = DesignTokens.ColorPrimary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(DesignTokens.Spacing16))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = DesignTokens.ColorPrimary
            )
        )
    }
}
