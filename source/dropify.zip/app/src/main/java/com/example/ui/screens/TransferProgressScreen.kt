package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.TransferDirection
import com.example.data.model.TransferSession
import com.example.ui.components.DeviceToDeviceTransferAnimation
import com.example.ui.theme.DesignTokens

@Composable
fun TransferProgressScreen(
    session: TransferSession,
    localDeviceName: String = "My Device",
    localAvatarId: Int = 0,
    onCancelTransfer: () -> Unit
) {
    val isSending = session.direction == TransferDirection.SEND

    val senderName = if (isSending) localDeviceName else session.remoteDeviceName
    val senderAvatarId = if (isSending) localAvatarId else session.remoteAvatarId
    val receiverName = if (isSending) session.remoteDeviceName else localDeviceName
    val receiverAvatarId = if (isSending) session.remoteAvatarId else localAvatarId

    val currentFile = session.files.getOrNull(session.currentFileIndex) ?: session.files.firstOrNull()

    // Smooth progress interpolation for bar and percent
    val animatedProgressFraction by animateFloatAsState(
        targetValue = session.progressFraction.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
        label = "progressBarFraction"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(horizontal = DesignTokens.Spacing16)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(DesignTokens.Spacing12))

        // Hero Device-to-Device Beaming Animation with Particle Transitions
        DeviceToDeviceTransferAnimation(
            senderName = senderName,
            senderAvatarId = senderAvatarId,
            receiverName = receiverName,
            receiverAvatarId = receiverAvatarId,
            progressFraction = session.progressFraction,
            transferSpeedBps = session.transferSpeedBytesPerSec,
            currentFileName = currentFile?.name,
            currentFileType = currentFile?.mimeType
        )

        Spacer(modifier = Modifier.height(DesignTokens.Spacing20))

        // Large Progress Percentage
        Text(
            text = "${(animatedProgressFraction * 100).toInt()}%",
            style = MaterialTheme.typography.displayMedium.copy(
                fontWeight = FontWeight.Black,
                fontSize = 54.sp
            ),
            color = DesignTokens.ColorPrimary
        )

        Spacer(modifier = Modifier.height(DesignTokens.Spacing4))

        // Transferred Bytes in Badge
        Box(
            modifier = Modifier
                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(DesignTokens.RadiusMd))
                .border(
                    1.dp,
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                    RoundedCornerShape(DesignTokens.RadiusMd)
                )
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Text(
                text = session.getFormattedTransferred(),
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        Spacer(modifier = Modifier.height(DesignTokens.Spacing16))

        // Fluid Ultramarine Linear Progress
        LinearProgressIndicator(
            progress = { animatedProgressFraction },
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(DesignTokens.RadiusMd)),
            color = DesignTokens.ColorPrimary,
            trackColor = DesignTokens.ColorBg3,
            strokeCap = StrokeCap.Round
        )

        Spacer(modifier = Modifier.height(DesignTokens.Spacing20))

        // Telemetry Grid (Speed, Remaining Time)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(DesignTokens.Spacing12)
        ) {
            TelemetryCard(
                label = "Speed",
                value = session.getFormattedSpeed(),
                icon = Icons.Default.Speed,
                iconTint = DesignTokens.ColorPrimary,
                modifier = Modifier.weight(1f)
            )

            TelemetryCard(
                label = "Remaining",
                value = session.getFormattedRemainingTime(),
                icon = Icons.Default.Timer,
                iconTint = Color(0xFF00C48C),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(DesignTokens.Spacing16))

        // Current File info card
        if (currentFile != null) {
            Surface(
                shape = RoundedCornerShape(DesignTokens.RadiusXl),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                        RoundedCornerShape(DesignTokens.RadiusXl)
                    )
            ) {
                Row(
                    modifier = Modifier.padding(DesignTokens.Spacing16),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(DesignTokens.ColorBg3, RoundedCornerShape(DesignTokens.RadiusMd)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = DesignTokens.ColorPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(DesignTokens.Spacing12))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentFile.name,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${currentFile.getFormattedSize()} • ${session.files.size} total files",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(DesignTokens.Spacing24))

        // Cancel Button in Pill Shape
        OutlinedButton(
            onClick = onCancelTransfer,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .navigationBarsPadding()
                .testTag("cancel_transfer_button"),
            shape = RoundedCornerShape(DesignTokens.RadiusMd),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFF4861)),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = Color(0xFFFF4861)
            )
        ) {
            Icon(imageVector = Icons.Default.Close, contentDescription = null)
            Spacer(modifier = Modifier.width(DesignTokens.Spacing8))
            Text(
                text = stringResource(id = R.string.cancel),
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(DesignTokens.Spacing16))
    }
}

@Composable
private fun TelemetryCard(
    label: String,
    value: String,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(DesignTokens.RadiusXl),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = modifier.border(
            1.dp,
            MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
            RoundedCornerShape(DesignTokens.RadiusXl)
        )
    ) {
        Column(modifier = Modifier.padding(DesignTokens.Spacing16)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(iconTint.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(DesignTokens.Spacing8))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
