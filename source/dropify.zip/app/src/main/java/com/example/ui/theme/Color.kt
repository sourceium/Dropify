package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Ultramarine / Indigo from DesignTokens (#4D43FE)
val BrandPrimary = DesignTokens.ColorPrimary
val BrandPrimaryLight = DesignTokens.RampPrimary400
val BrandPrimaryDark = DesignTokens.RampPrimary800
val BrandPrimaryContainer = DesignTokens.ColorBg3
val BrandPrimaryContainerDark = DesignTokens.RampPrimary950

// Accents
val AccentEmerald = Color(0xFF00C48C)
val AccentAmber = Color(0xFFFFB020)
val AccentRose = Color(0xFFFF4861)

// Light Theme Neutrals
val LightBackground = DesignTokens.NeutralLightBg
val LightSurface = DesignTokens.SurfacePageBg
val LightSurfaceVariant = DesignTokens.RampNeutral50
val LightOnSurface = DesignTokens.SurfacePageFg
val LightOnSurfaceVariant = DesignTokens.RampNeutral600
val LightOutline = DesignTokens.NeutralBorder

// Dark Theme Neutrals
val DarkBackground = DesignTokens.ColorBg1
val DarkSurface = Color(0xFF242426)
val DarkSurfaceVariant = Color(0xFF2E2E32)
val DarkOnSurface = DesignTokens.NeutralWhite
val DarkOnSurfaceVariant = DesignTokens.NeutralMuted
val DarkOutline = Color(0xFF38383C)
