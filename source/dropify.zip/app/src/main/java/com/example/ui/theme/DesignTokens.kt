package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object DesignTokens {
    // Colors — Primary & Brand
    val ColorPrimary = Color(0xFF4D43FE)
    val ColorBrand = Color(0xFF4D43FE)
    val ColorAction = Color(0xFF4D43FE)

    // Ramp — Primary (base is 600: #4D43FE)
    val RampPrimary50 = Color(0xFFD7ECFF)
    val RampPrimary100 = Color(0xFFC9DFFF)
    val RampPrimary200 = Color(0xFFB5CBFF)
    val RampPrimary300 = Color(0xFF9AADFF)
    val RampPrimary400 = Color(0xFF7985FF)
    val RampPrimary500 = Color(0xFF5F60FF)
    val RampPrimary600 = Color(0xFF4D43FE)
    val RampPrimary700 = Color(0xFF3D33D3)
    val RampPrimary800 = Color(0xFF3124B4)
    val RampPrimary900 = Color(0xFF271898)
    val RampPrimary950 = Color(0xFF14055F)

    // Ramp — Neutral (base is 950: #1B1B1B)
    val RampNeutral50 = Color(0xFFF5F5F5)
    val RampNeutral100 = Color(0xFFEAEAEA)
    val RampNeutral200 = Color(0xFFD9D9D9)
    val RampNeutral300 = Color(0xFFC0C0C0)
    val RampNeutral400 = Color(0xFF9F9F9F)
    val RampNeutral500 = Color(0xFF828282)
    val RampNeutral600 = Color(0xFF6C6C6C)
    val RampNeutral700 = Color(0xFF575757)
    val RampNeutral800 = Color(0xFF464646)
    val RampNeutral900 = Color(0xFF393939)
    val RampNeutral950 = Color(0xFF1B1B1B)

    // Colors — Neutrals
    val NeutralBorder = Color(0xFFE5E7EB)
    val NeutralDark = Color(0xFF1B1B1B)
    val NeutralWhite = Color(0xFFFFFFFF)
    val NeutralBlack = Color(0xFF000000)
    val NeutralMuted = Color(0xFFADACBE)
    val NeutralLightBg = Color(0xFFEEF4FE)

    // Colors — Backgrounds
    val ColorBg = Color(0xFFFFFFFF)
    val ColorBg1 = Color(0xFF1B1B1B)
    val ColorBg2 = Color(0xFF4D43FE)
    val ColorBg3 = Color(0xFFE0EAFF)

    // Super Blue
    val SuperBlue50 = Color(0xFFDBE1FF)

    // Colors — Text
    val ColorText = Color(0xFFFFFFFF)
    val ColorText1 = Color(0xFF1B1B1B)
    val ColorText2 = Color(0xFF4D43FE)
    val ColorText3 = Color(0xFFADACBE)
    val ColorText4 = Color(0xFFEAECF0)

    // Semantic pairs
    val SurfacePageBg = Color(0xFFFFFFFF)
    val SurfacePageFg = Color(0xFF1B1B1B) // 17.22:1 AAA
    val SurfaceRaisedBg = Color(0xFF1B1B1B)
    val SurfaceRaisedFg = Color(0xFFFFFFFF) // 17.22:1 AAA
    val ActionPrimaryBg = Color(0xFF4D43FE)
    val ActionPrimaryFg = Color(0xFFFFFFFF) // 5.92:1 AA

    // Shadows
    val ShadowXs = Color(0x1A4A3AFF)
    val ShadowSm = Color(0x73291EFF)

    // Spacing scale
    val Spacing4 = 4.dp
    val Spacing8 = 8.dp
    val Spacing12 = 12.dp
    val Spacing16 = 16.dp
    val Spacing20 = 20.dp
    val Spacing24 = 24.dp
    val Spacing32 = 32.dp
    val Spacing36 = 36.dp
    val Spacing40 = 40.dp
    val Spacing48 = 48.dp
    val Spacing128 = 128.dp
    val Spacing320 = 320.dp

    // Border Radius — "md · 10" token standard applied across all sections
    val RadiusNone = 0.dp
    val RadiusXs = 4.dp
    val RadiusSm = 6.dp
    val RadiusMd = 10.dp // md · 10
    val RadiusLg = 10.dp // md · 10
    val RadiusXl = 10.dp // md · 10
    val RadiusFull = 9999.dp

    // Backward-compatible aliases
    val BrandPrimary = ColorPrimary
    val BrandIdentity = ColorBrand
    val BrandAction = ColorAction
    val ActionPrimary = ActionPrimaryBg
    val ActionOnPrimary = ActionPrimaryFg
    val SurfaceDefault = SurfacePageBg
    val SurfacePage = SurfacePageBg
    val SurfaceOnPage = SurfacePageFg
    val SurfaceRaised = SurfaceRaisedBg
    val SurfaceOnRaised = SurfaceRaisedFg
    val NeutralN100 = NeutralBorder
    val NeutralN200 = NeutralDark
    val NeutralN300 = NeutralWhite
    val NeutralN400 = NeutralBlack
    val NeutralN500 = NeutralMuted
    val NeutralN600 = NeutralLightBg
    val BackgroundBg0 = ColorBg
    val BackgroundBg1 = ColorBg1
    val BackgroundBg2 = ColorBg2
    val BackgroundBg3 = ColorBg3
    val TextText0 = ColorText
    val TextText1 = ColorText1
    val TextText2 = ColorText2
    val TextText3 = ColorText3
    val TextText4 = ColorText4

    val SpacingS0 = Spacing4
    val SpacingS1 = Spacing12
    val SpacingS2 = Spacing16
    val SpacingS3 = Spacing20
    val SpacingS4 = Spacing24
    val SpacingS5 = Spacing32
    val SpacingS6 = Spacing36
    val SpacingS7 = Spacing40
    val SpacingS8 = Spacing48
    val SpacingS9 = Spacing128
    val SpacingS10 = Spacing320

    val RadiusR0 = 10.dp // md · 10
    val RadiusR1 = 10.dp // md · 10
    val RadiusR2 = 10.dp // md · 10
    val RadiusR3 = 10.dp // md · 10
    val RadiusR4 = 10.dp // md · 10
    val RadiusR5 = 10.dp // md · 10
}
