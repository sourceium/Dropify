package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DesignTokens.RampPrimary400,
    onPrimary = DesignTokens.RampPrimary950,
    primaryContainer = DesignTokens.RampPrimary950,
    onPrimaryContainer = DesignTokens.RampPrimary100,
    secondary = DesignTokens.RampPrimary300,
    onSecondary = DesignTokens.RampPrimary950,
    secondaryContainer = Color(0xFF2E2E38),
    onSecondaryContainer = DesignTokens.RampPrimary100,
    background = DesignTokens.ColorBg1,
    onBackground = DesignTokens.NeutralWhite,
    surface = Color(0xFF242426),
    onSurface = DesignTokens.NeutralWhite,
    surfaceVariant = Color(0xFF2E2E32),
    onSurfaceVariant = DesignTokens.NeutralMuted,
    outline = Color(0xFF38383C),
    outlineVariant = Color(0xFF2A2A2E)
)

private val LightColorScheme = lightColorScheme(
    primary = DesignTokens.ColorPrimary,
    onPrimary = DesignTokens.ActionPrimaryFg,
    primaryContainer = DesignTokens.ColorBg3,
    onPrimaryContainer = DesignTokens.RampPrimary900,
    secondary = DesignTokens.RampPrimary700,
    onSecondary = DesignTokens.ActionPrimaryFg,
    secondaryContainer = DesignTokens.NeutralLightBg,
    onSecondaryContainer = DesignTokens.SurfacePageFg,
    background = DesignTokens.NeutralLightBg,
    onBackground = DesignTokens.SurfacePageFg,
    surface = DesignTokens.SurfacePageBg,
    onSurface = DesignTokens.SurfacePageFg,
    surfaceVariant = DesignTokens.NeutralLightBg,
    onSurfaceVariant = DesignTokens.RampNeutral600,
    outline = DesignTokens.NeutralBorder,
    outlineVariant = DesignTokens.RampNeutral100
)

val AppShapes = androidx.compose.material3.Shapes(
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(DesignTokens.RadiusMd),
    small = androidx.compose.foundation.shape.RoundedCornerShape(DesignTokens.RadiusMd),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(DesignTokens.RadiusMd),
    large = androidx.compose.foundation.shape.RoundedCornerShape(DesignTokens.RadiusMd),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(DesignTokens.RadiusMd)
)

@Composable
fun DropifyTheme(
    themeSetting: String = "system",
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val systemDark = isSystemInDarkTheme()
    val isDark = when (themeSetting.lowercase()) {
        "dark" -> true
        "light" -> false
        else -> systemDark
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (isDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        isDark -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}

@Composable
fun GlideShareTheme(
    themeSetting: String = "system",
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) = DropifyTheme(themeSetting, dynamicColor, content)
