package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

// Font Families matching CSS: --font-sans: 'AnekLatin' and --font-font-1: 'Figtree'
val AnekLatinFontFamily = FontFamily(
    Font(R.font.anek_latin, FontWeight.Normal),
    Font(R.font.anek_latin, FontWeight.Medium),
    Font(R.font.anek_latin, FontWeight.SemiBold),
    Font(R.font.anek_latin, FontWeight.Bold),
    Font(R.font.anek_latin, FontWeight.ExtraBold)
)

val FigtreeFontFamily = FontFamily(
    Font(R.font.figtree, FontWeight.Normal),
    Font(R.font.figtree, FontWeight.Medium),
    Font(R.font.figtree, FontWeight.SemiBold),
    Font(R.font.figtree, FontWeight.Bold)
)

// Named typographic scale from design tokens
val Typography = Typography(
    displayLarge = TextStyle(
        fontFamily = AnekLatinFontFamily,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 44.sp,
        lineHeight = 48.sp,
        letterSpacing = (-0.5).sp
    ),
    displayMedium = TextStyle(
        fontFamily = AnekLatinFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 36.sp,
        lineHeight = 42.sp,
        letterSpacing = (-0.5).sp
    ),
    displaySmall = TextStyle(
        fontFamily = AnekLatinFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp, // --font-size-title-4: 32px
        lineHeight = 38.sp
    ),
    headlineLarge = TextStyle(
        fontFamily = AnekLatinFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp, // --font-size-title-5: 28px
        lineHeight = 34.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = AnekLatinFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp, // --font-size-title-6: 24px
        lineHeight = 30.sp
    ),
    headlineSmall = TextStyle(
        fontFamily = AnekLatinFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp, // --font-size-title-7: 22px
        lineHeight = 28.sp
    ),
    titleLarge = TextStyle(
        fontFamily = AnekLatinFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp, // --font-size-h3: 20px
        lineHeight = 26.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FigtreeFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp, // --font-size-title-8: 16px
        lineHeight = 22.sp
    ),
    titleSmall = TextStyle(
        fontFamily = FigtreeFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FigtreeFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.2.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FigtreeFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp, // --font-size-body: 14px
        lineHeight = 20.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FigtreeFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.3.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FigtreeFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        lineHeight = 18.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FigtreeFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp,
        lineHeight = 16.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FigtreeFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.4.sp
    )
)
