package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.DropifyApp
import com.example.data.db.TransferEntity
import com.example.data.model.DeviceConnectionState
import com.example.data.model.DiscoveredDevice
import com.example.data.model.FileItem
import com.example.data.model.FileMetadata
import com.example.data.model.QrPairingData
import com.example.data.model.TransferDirection
import com.example.data.model.TransferSession
import com.example.data.model.TransferState
import com.example.data.preferences.UserPreferences
import com.example.service.TransferForegroundService
import com.example.storage.FileStorageManager
import com.example.transport.ConnectionRequest
import com.example.transport.NearbyTransportProvider
import com.example.transport.TransportProvider
import com.example.transport.TransportProviderListener
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application), TransportProviderListener {

    private val app = application as DropifyApp
    private val preferencesManager = app.preferencesManager
    private val transferRepository = app.transferRepository
    private val storageManager = FileStorageManager(application)

    val userPreferences: StateFlow<UserPreferences> = preferencesManager.userPreferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = UserPreferences(
                deviceName = "Dropify Device",
                avatarId = 0,
                isProfileConfigured = false,
                themeSetting = "system",
                isDeviceVisible = true,
                notificationsEnabled = true,
                isProPurchased = false,
                receiveFolder = "Downloads/Dropify",
                isLoaded = false
            )
        )

    val historyTransfers = transferRepository.allTransfers
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val transportProvider: TransportProvider = NearbyTransportProvider(application, this)

    // Send flow state
    private val _selectedFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val selectedFiles: StateFlow<List<FileItem>> = _selectedFiles.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<DiscoveredDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<DiscoveredDevice>> = _discoveredDevices.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    private val _isAdvertising = MutableStateFlow(false)
    val isAdvertising: StateFlow<Boolean> = _isAdvertising.asStateFlow()

    // Connection & Active transfer state
    private val _connectedEndpointId = MutableStateFlow<String?>(null)
    val connectedEndpointId: StateFlow<String?> = _connectedEndpointId.asStateFlow()

    private val _incomingRequest = MutableStateFlow<ConnectionRequest?>(null)
    val incomingRequest: StateFlow<ConnectionRequest?> = _incomingRequest.asStateFlow()

    private val _incomingFilesMetadata = MutableStateFlow<List<FileItem>>(emptyList())
    val incomingFilesMetadata: StateFlow<List<FileItem>> = _incomingFilesMetadata.asStateFlow()

    private val _activeSession = MutableStateFlow<TransferSession?>(null)
    val activeSession: StateFlow<TransferSession?> = _activeSession.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    // Tracking speed calculation
    private var lastBytesTransferred = 0L
    private var lastSpeedCheckTime = 0L
    private val payloadToFileMap = mutableMapOf<Long, FileItem>()
    private val receivedFilesList = mutableListOf<FileItem>()

    fun saveProfile(name: String, avatarId: Int) {
        viewModelScope.launch {
            preferencesManager.saveProfile(name, avatarId)
        }
    }

    fun setThemeSetting(theme: String) {
        viewModelScope.launch {
            preferencesManager.setThemeSetting(theme)
        }
    }

    fun setDeviceVisibility(visible: Boolean) {
        viewModelScope.launch {
            preferencesManager.setDeviceVisibility(visible)
            if (!visible && isAdvertising.value) {
                stopAdvertising()
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            transferRepository.clearHistory()
        }
    }

    fun addSelectedFiles(files: List<FileItem>) {
        val current = _selectedFiles.value.toMutableList()
        for (file in files) {
            if (current.none { it.uri == file.uri }) {
                current.add(file)
            }
        }
        _selectedFiles.value = current
    }

    fun removeSelectedFile(file: FileItem) {
        _selectedFiles.value = _selectedFiles.value.filter { it.uri != file.uri }
    }

    fun clearSelectedFiles() {
        _selectedFiles.value = emptyList()
    }

    // Discovery (Send)
    fun startDiscovery() {
        _discoveredDevices.value = emptyList()
        transportProvider.startDiscovery()
        _isDiscovering.value = true
    }

    fun stopDiscovery() {
        transportProvider.stopDiscovery()
        _isDiscovering.value = false
    }

    // Advertising (Receive)
    fun startAdvertising() {
        val prefs = userPreferences.value
        transportProvider.startAdvertising(prefs.deviceName, prefs.avatarId)
        _isAdvertising.value = true
    }

    fun stopAdvertising() {
        transportProvider.stopAdvertising()
        _isAdvertising.value = false
    }

    fun connectToDevice(device: DiscoveredDevice) {
        val prefs = userPreferences.value
        _discoveredDevices.value = _discoveredDevices.value.map {
            if (it.endpointId == device.endpointId) {
                it.copy(connectionState = DeviceConnectionState.CONNECTING)
            } else it
        }
        transportProvider.connect(device.endpointId, prefs.deviceName, prefs.avatarId)
    }

    fun acceptIncomingRequest() {
        val request = _incomingRequest.value ?: return
        transportProvider.acceptConnection(request.endpointId)
        _incomingRequest.value = null
    }

    fun declineIncomingRequest() {
        val request = _incomingRequest.value ?: return
        transportProvider.rejectConnection(request.endpointId)
        _incomingRequest.value = null
        _incomingFilesMetadata.value = emptyList()
    }

    fun cancelActiveTransfer() {
        val endpoint = _connectedEndpointId.value
        if (endpoint != null) {
            transportProvider.disconnect(endpoint)
        }
        transportProvider.stopAll()
        TransferForegroundService.stop(getApplication())

        _activeSession.value?.let { session ->
            _activeSession.value = session.copy(state = TransferState.CANCELLED)
            recordTransferHistory(session.copy(state = TransferState.CANCELLED))
        }
    }

    fun resetTransferSession() {
        _activeSession.value = null
        _incomingFilesMetadata.value = emptyList()
        clearSelectedFiles()
    }

    fun generateQrPairingData(): String {
        val prefs = userPreferences.value
        val endpoint = _connectedEndpointId.value ?: "ENDPOINT_${System.currentTimeMillis() % 10000}"
        val data = QrPairingData(
            deviceName = prefs.deviceName,
            avatarId = prefs.avatarId,
            endpointId = endpoint,
            serviceId = "com.HaldarAi.Dropify",
            timestamp = System.currentTimeMillis()
        )
        return data.toJson()
    }

    fun handleQrScanResult(scannedJson: String) {
        val qrData = QrPairingData.fromJson(scannedJson)
        if (qrData == null) {
            _statusMessage.value = "Invalid QR code format."
            return
        }
        if (qrData.isExpired) {
            _statusMessage.value = "This QR code has expired. Please refresh on recipient device."
            return
        }

        // Add to discovered devices list and initiate connection
        val device = DiscoveredDevice(
            endpointId = qrData.endpointId,
            name = qrData.deviceName,
            avatarId = qrData.avatarId,
            connectionState = DeviceConnectionState.DISCOVERED
        )
        _discoveredDevices.value = listOf(device) + _discoveredDevices.value.filter { it.endpointId != device.endpointId }
        connectToDevice(device)
    }

    // TransportProviderListener callbacks
    override fun onDeviceFound(device: DiscoveredDevice) {
        val current = _discoveredDevices.value.toMutableList()
        val index = current.indexOfFirst { it.endpointId == device.endpointId }
        if (index >= 0) {
            current[index] = device
        } else {
            current.add(device)
        }
        _discoveredDevices.value = current
    }

    override fun onDeviceLost(endpointId: String) {
        _discoveredDevices.value = _discoveredDevices.value.filter { it.endpointId != endpointId }
    }

    override fun onConnectionInitiated(request: ConnectionRequest) {
        if (request.isIncomingConnection) {
            // Recipient sees incoming connection prompt
            _incomingRequest.value = request
        } else {
            // Sender automatically accepts connection initiation callback
            transportProvider.acceptConnection(request.endpointId)
        }
    }

    override fun onConnected(endpointId: String) {
        _connectedEndpointId.value = endpointId
        _isDiscovering.value = false
        _isAdvertising.value = false

        // If we are sender, send metadata of selected files
        val files = _selectedFiles.value
        if (files.isNotEmpty()) {
            val totalBytes = files.sumOf { it.size }
            val session = TransferSession(
                sessionId = "SESSION_${System.currentTimeMillis()}",
                direction = TransferDirection.SEND,
                remoteDeviceName = _discoveredDevices.value.find { it.endpointId == endpointId }?.name ?: "Receiver",
                remoteAvatarId = _discoveredDevices.value.find { it.endpointId == endpointId }?.avatarId ?: 0,
                files = files,
                totalBytes = totalBytes,
                state = TransferState.ACCEPTED
            )
            _activeSession.value = session

            // Send metadata JSON
            val metaJson = buildMetadataJson(files)
            transportProvider.sendMetadata(endpointId, metaJson)

            // Begin sending payloads
            startSendingFiles(endpointId, files)
        }
    }

    private fun startSendingFiles(endpointId: String, files: List<FileItem>) {
        viewModelScope.launch(Dispatchers.IO) {
            _activeSession.value = _activeSession.value?.copy(state = TransferState.TRANSFERRING)
            TransferForegroundService.startOrUpdate(
                getApplication(),
                "Sending files to ${_activeSession.value?.remoteDeviceName}",
                "0% transferred",
                0
            )

            lastBytesTransferred = 0L
            lastSpeedCheckTime = System.currentTimeMillis()

            for (file in files) {
                val payloadId = transportProvider.sendFile(endpointId, file.uri)
                if (payloadId != null) {
                    payloadToFileMap[payloadId] = file
                }
            }
        }
    }

    private fun buildMetadataJson(files: List<FileItem>): String {
        val root = JSONObject()
        val array = JSONArray()
        for (f in files) {
            val item = JSONObject().apply {
                put("name", f.name)
                put("size", f.size)
                put("mime", f.mimeType)
            }
            array.put(item)
        }
        root.put("files", array)
        return root.toString()
    }

    override fun onMetadataReceived(endpointId: String, metadataJson: String) {
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val root = JSONObject(metadataJson)
                val array = root.getJSONArray("files")
                val files = mutableListOf<FileItem>()
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    files.add(
                        FileItem(
                            uri = Uri.EMPTY,
                            name = item.getString("name"),
                            size = item.getLong("size"),
                            mimeType = item.optString("mime", "application/octet-stream")
                        )
                    )
                }
                _incomingFilesMetadata.value = files

                // Create receiver active session
                val totalBytes = files.sumOf { it.size }
                _activeSession.value = TransferSession(
                    sessionId = "SESSION_${System.currentTimeMillis()}",
                    direction = TransferDirection.RECEIVE,
                    remoteDeviceName = "Sender Device",
                    remoteAvatarId = 0,
                    files = files,
                    totalBytes = totalBytes,
                    state = TransferState.TRANSFERRING
                )

                lastBytesTransferred = 0L
                lastSpeedCheckTime = System.currentTimeMillis()
                receivedFilesList.clear()

                TransferForegroundService.startOrUpdate(
                    getApplication(),
                    "Receiving files",
                    "0% completed",
                    0
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onPayloadTransferUpdate(
        endpointId: String,
        payloadId: Long,
        bytesTransferred: Long,
        totalBytes: Long,
        status: Int
    ) {
        val session = _activeSession.value ?: return
        val now = System.currentTimeMillis()
        val timeDeltaMs = (now - lastSpeedCheckTime).coerceAtLeast(1)

        val bytesDelta = (bytesTransferred - lastBytesTransferred).coerceAtLeast(0)
        val speedBytesPerSec = if (timeDeltaMs > 200) {
            val calculatedSpeed = (bytesDelta * 1000) / timeDeltaMs
            lastSpeedCheckTime = now
            lastBytesTransferred = bytesTransferred
            calculatedSpeed
        } else {
            session.transferSpeedBytesPerSec
        }

        val updatedSession = session.copy(
            bytesTransferred = bytesTransferred,
            totalBytes = if (totalBytes > 0) totalBytes else session.totalBytes,
            transferSpeedBytesPerSec = speedBytesPerSec
        )
        _activeSession.value = updatedSession

        // Update foreground service notification
        TransferForegroundService.startOrUpdate(
            getApplication(),
            if (session.direction == TransferDirection.SEND) "Sending files" else "Receiving files",
            "${updatedSession.progressPercent}% • ${updatedSession.getFormattedSpeed()}",
            updatedSession.progressPercent
        )

        if (status == PayloadTransferUpdate.Status.SUCCESS) {
            if (bytesTransferred >= session.totalBytes && session.totalBytes > 0) {
                val completedSession = updatedSession.copy(state = TransferState.COMPLETED)
                _activeSession.value = completedSession
                TransferForegroundService.stop(getApplication())
                recordTransferHistory(completedSession)
            }
        } else if (status == PayloadTransferUpdate.Status.FAILURE) {
            val failedSession = updatedSession.copy(state = TransferState.FAILED, errorMessage = "Transfer interrupted")
            _activeSession.value = failedSession
            TransferForegroundService.stop(getApplication())
            recordTransferHistory(failedSession)
        }
    }

    override fun onFilePayloadReceived(endpointId: String, payloadId: Long, incomingFile: File) {
        viewModelScope.launch(Dispatchers.IO) {
            val metadataFiles = _incomingFilesMetadata.value
            val currentIdx = receivedFilesList.size
            val matchedMeta = metadataFiles.getOrNull(currentIdx) ?: FileItem(
                uri = Uri.EMPTY,
                name = incomingFile.name,
                size = incomingFile.length(),
                mimeType = "application/octet-stream"
            )

            val finalizedUri = storageManager.finalizeReceivedFile(
                partialFile = incomingFile,
                originalFileName = matchedMeta.name,
                mimeType = matchedMeta.mimeType
            )

            if (finalizedUri != null) {
                receivedFilesList.add(matchedMeta.copy(uri = finalizedUri))
            }

            if (receivedFilesList.size >= metadataFiles.size && metadataFiles.isNotEmpty()) {
                val completedSession = _activeSession.value?.copy(
                    state = TransferState.COMPLETED,
                    bytesTransferred = _activeSession.value?.totalBytes ?: 0L
                )
                if (completedSession != null) {
                    _activeSession.value = completedSession
                    TransferForegroundService.stop(getApplication())
                    recordTransferHistory(completedSession)
                }
            }
        }
    }

    fun deleteTransfer(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            transferRepository.deleteById(id)
        }
    }

    private fun recordTransferHistory(session: TransferSession) {
        viewModelScope.launch(Dispatchers.IO) {
            val metadataList = session.files.map {
                FileMetadata(
                    name = it.name,
                    size = it.size,
                    mimeType = it.mimeType,
                    uri = it.uri.toString()
                )
            }
            val names = session.files.joinToString(", ") { it.name }
            val entity = TransferEntity(
                direction = if (session.direction == TransferDirection.SEND) "SENT" else "RECEIVED",
                deviceName = session.remoteDeviceName,
                avatarId = session.remoteAvatarId,
                fileCount = session.files.size,
                totalBytes = session.totalBytes,
                status = session.state.name,
                speedBps = session.transferSpeedBytesPerSec,
                fileNames = names,
                files = metadataList
            )
            transferRepository.insertTransfer(entity)
        }
    }

    override fun onDisconnected(endpointId: String) {
        if (_connectedEndpointId.value == endpointId) {
            _connectedEndpointId.value = null
            if (_activeSession.value?.state == TransferState.TRANSFERRING) {
                val failed = _activeSession.value?.copy(
                    state = TransferState.FAILED,
                    errorMessage = "Connection lost with remote device"
                )
                _activeSession.value = failed
                if (failed != null) recordTransferHistory(failed)
                TransferForegroundService.stop(getApplication())
            }
        }
    }

    override fun onError(message: String) {
        _statusMessage.value = message
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        transportProvider.stopAll()
        TransferForegroundService.stop(getApplication())
    }
}
