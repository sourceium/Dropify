package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.AppDatabase
import com.example.data.db.TransferEntity
import com.example.data.model.FileMetadata
import com.example.data.preferences.PreferencesManager
import com.example.data.repository.TransferRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private lateinit var database: AppDatabase
  private lateinit var repository: TransferRepository

  @Before
  fun setup() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    repository = TransferRepository(database.transferDao())
  }

  @After
  fun tearDown() {
    database.close()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Dropify", appName)
  }

  @Test
  fun `profile configuration persists once saved`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val preferencesManager = PreferencesManager(context)

    preferencesManager.saveProfile("Test Phone", 3)

    assertTrue("isProfileConfigured should return true after saving", preferencesManager.isProfileConfigured())
    val userPrefs = preferencesManager.userPreferencesFlow.first()
    assertTrue("userPrefs.isProfileConfigured should be true", userPrefs.isProfileConfigured)
    assertEquals("Test Phone", userPrefs.deviceName)
    assertEquals(3, userPrefs.avatarId)
  }

  @Test
  fun `room transfer entity persists with timestamps and file metadata`() = runBlocking {
    val testFiles = listOf(
      FileMetadata(
        name = "vacation_photo.jpg",
        size = 3_450_000L,
        mimeType = "image/jpeg",
        uri = "content://media/external/images/media/1"
      ),
      FileMetadata(
        name = "project_report.pdf",
        size = 1_200_000L,
        mimeType = "application/pdf",
        uri = "content://media/external/files/2"
      )
    )

    val entity = TransferEntity(
      timestamp = System.currentTimeMillis(),
      direction = "SENT",
      deviceName = "Pixel 8 Pro",
      avatarId = 1,
      fileCount = 2,
      totalBytes = 4_650_000L,
      status = "COMPLETED",
      speedBps = 15_000_000L,
      fileNames = "vacation_photo.jpg, project_report.pdf",
      files = testFiles
    )

    val insertedId = repository.insertTransfer(entity)
    assertTrue("Inserted ID should be greater than 0", insertedId > 0)

    val retrieved = repository.getTransferById(insertedId)
    assertNotNull("Retrieved entity should not be null", retrieved)
    assertEquals("SENT", retrieved?.direction)
    assertEquals("Pixel 8 Pro", retrieved?.deviceName)
    assertEquals(2, retrieved?.fileCount)
    assertEquals(4_650_000L, retrieved?.totalBytes)
    assertEquals("COMPLETED", retrieved?.status)
    assertEquals(2, retrieved?.files?.size)

    val firstFile = retrieved?.files?.firstOrNull()
    assertNotNull(firstFile)
    assertEquals("vacation_photo.jpg", firstFile?.name)
    assertEquals("image/jpeg", firstFile?.mimeType)
    assertEquals("JPG", firstFile?.getFileExtension())
    assertEquals("Image", firstFile?.getCategoryName())
  }

  @Test
  fun `room repository flows support filtering and searching`() = runBlocking {
    val transfer1 = TransferEntity(
      timestamp = 1000L,
      direction = "SENT",
      deviceName = "Galaxy S24",
      avatarId = 2,
      fileCount = 1,
      totalBytes = 500_000L,
      status = "COMPLETED",
      fileNames = "presentation.key",
      files = listOf(FileMetadata("presentation.key", 500_000L, "application/octet-stream"))
    )

    val transfer2 = TransferEntity(
      timestamp = 2000L,
      direction = "RECEIVED",
      deviceName = "MacBook Pro",
      avatarId = 3,
      fileCount = 1,
      totalBytes = 10_000_000L,
      status = "COMPLETED",
      fileNames = "archive.zip",
      files = listOf(FileMetadata("archive.zip", 10_000_000L, "application/zip"))
    )

    repository.insertTransfer(transfer1)
    val id2 = repository.insertTransfer(transfer2)

    val allTransfers = repository.allTransfers.first()
    assertEquals(2, allTransfers.size)

    val sentOnly = repository.getTransfersByDirection("SENT").first()
    assertEquals(1, sentOnly.size)
    assertEquals("Galaxy S24", sentOnly[0].deviceName)

    val receivedOnly = repository.getTransfersByDirection("RECEIVED").first()
    assertEquals(1, receivedOnly.size)
    assertEquals("MacBook Pro", receivedOnly[0].deviceName)

    val searchResult = repository.searchTransfers("archive").first()
    assertEquals(1, searchResult.size)
    assertEquals("MacBook Pro", searchResult[0].deviceName)

    repository.deleteById(id2)
    val afterDelete = repository.allTransfers.first()
    assertEquals(1, afterDelete.size)
    assertEquals("Galaxy S24", afterDelete[0].deviceName)

    repository.clearHistory()
    val afterClear = repository.allTransfers.first()
    assertTrue(afterClear.isEmpty())
  }
}
