# QuickShare-Style Simple Premium Android File Sharing App

## 1. Product Scope

Build a real Android-to-Android nearby file-sharing app inspired by the simplicity of Quick Share, not a copy of Quick Share or InShare.

Core only:
- Splash
- Profile/avatar setup
- Home
- Send
- Receive
- Real nearby-device discovery
- Real file transfer
- Transfer progress
- Transfer complete
- History
- Settings
- AdMob bottom banner
- Remove Ads / Pro
- QR fallback

Strictly do NOT add demo videos, sample files, fake devices, fake history, fake progress, fake speeds, simulated discovery, fake successful transfers, unrelated utility tools, or a giant feature-filled dashboard.

## 2. What Current Quick Share Shows

Google's current Quick Share documentation describes a focused nearby-sharing experience: send/receive nearby content, device-visibility controls, accept/decline incoming transfers, QR-code fallback, transfer progress, notification-based transfer status/control, multi-file sharing, and selected-device multi-receiver sharing. Clipboard sharing exists on selected Android 13+ devices. Quick Share also supports Chromebooks and selected Windows PCs, with limited cross-platform support on compatible devices.

For this app, keep only the useful core Android-to-Android experience. Do not attempt to reproduce every Quick Share capability in v1.

## 3. Visual Direction From Supplied Screenshots

Use the screenshots as UX inspiration only:
- very simple home screen
- large Send and Receive actions
- clean Light Mode
- lots of breathing room without making the UI feel empty
- compact top bar
- simple side menu
- bottom ad area clearly separated from controls
- Remove Ads visible in menu/top area
- simple profile/avatar setup

Create original branding, icons, avatars, colors, illustrations and layouts. Do not copy InShare assets or reproduce its UI pixel-for-pixel.

## 4. Theme

LIGHT MODE is the primary design direction.

Light:
- near-white neutral background
- white surfaces
- dark text
- muted gray secondary text
- one modern brand accent
- subtle gradients only where they add polish

Dark:
- deep charcoal background
- slightly lighter surfaces
- near-white text
- muted secondary text
- same brand language as Light Mode

Theme options:
- System
- Light
- Dark

Default: System.

## 5. First Launch Flow

Splash
-> Profile Setup
-> Home

No long onboarding carousel and no tutorial/demo video.

## 6. Splash Screen

- original app logo
- app name
- short, subtle loading animation
- brief startup only

No promotional video, demo transfer or fake content.

## 7. Profile Setup Screen

Required on first launch.

Show:
- Profile heading
- large circular avatar
- device/profile name field
- 8–12 original avatar choices
- Save button

Behavior:
- store avatar and device name locally with DataStore
- no account creation
- no login
- no Google sign-in
- if blank, generate a local name such as "Rahul's Phone" but allow editing later

## 8. Home Screen

Keep it extremely simple.

Top bar:
- menu icon
- app logo/name
- optional small avatar

Main:
- large Send action
- large Receive action
- smaller History action

Optional status text:
- Ready to share
- Ready to receive

Bottom:
- dedicated AdMob banner container
- clear spacing between ad and controls
- no overlap with navigation or interactive controls

Do not add PC tools, web sharing, cleaners, games, feeds, recommendations or media utilities to v1.

## 9. Side Menu

Top:
- avatar
- device name

Menu:
- History
- Settings
- Remove Ads
- About

Nothing unrelated.

## 10. Send Flow

Home -> Send -> file picker -> selected-file review -> device discovery -> connection/authentication -> receiver acceptance -> transfer -> complete.

### File picking
Categories may be presented as quick entry points:
- Photos
- Videos
- Music
- Documents
- Other Files

Also provide Browse Files.

Use real Android pickers:
- Photo Picker where appropriate
- Storage Access Framework for arbitrary files
- multi-select

### Review screen
Show:
- real thumbnails where available
- filename
- size
- file type
- remove action
- selected count
- total size
- Continue

No fake file entries.

## 11. Device Discovery Screen

Premium but focused.

Heading:
Choose a device

Subtext:
Looking for nearby devices...

Center:
subtle animated discovery indicator

Below:
real discovered devices only.

Device card:
- avatar
- device name
- device type if actually available
- connection status

Fallback:
Scan QR

If nothing is found:
Can't find your device?
Scan QR code

Do not display hard-coded sample devices.
Do not claim exact distance unless the underlying API provides reliable data.

## 12. Connection / Verification

When a device is selected:
- request real connection
- authenticate using the chosen transport's available verification mechanism
- receiver sees a real incoming request

Receiver request:
Incoming transfer
From: device name
X files
Y MB/GB
[Decline] [Accept]

Never automatically accept normal incoming transfers.

## 13. Transfer Screen

Show real values only:
- sender/receiver device
- current file
- current-file progress
- overall progress
- bytes transferred
- total bytes
- current speed
- remaining time estimate
- files completed/remaining
- Cancel

Never hard-code speed or progress.
Never animate a timer as a fake transfer.

## 14. Receive Flow

Home -> Receive -> receiving/discovery mode -> incoming request -> Accept/Decline -> prepare destination -> real transfer -> complete.

Receive screen:
- Ready to receive
- device name
- visibility/ready status
- Stop Receiving
- Scan/Show QR as fallback where appropriate

## 15. Transfer Complete

Show:
- success indicator
- Transfer complete
- number of files
- total size
- optional average speed

Actions:
- Open Files
- Done

One subtle success animation is enough.

## 16. History

Secondary feature only.

Show real sent/received sessions:
- timestamp
- direction
- device
- file count
- total size
- status
- duration/speed where available

History details page can show per-file information.

Deleting history must not delete user files.

## 17. Settings

Keep it short.

### Profile
- Avatar
- Device name

### Appearance
- System
- Light
- Dark

### Receiving
- Receive folder
- visibility/receiving behavior

### Privacy
- device visibility
- clear history

### Notifications
- transfer notifications

### Premium
- Remove Ads

### About
- version
- privacy policy
- licenses

## 18. QR Code

QR is a real fallback when the device cannot be found normally.

Use short-lived, validated session/pairing data.

Must include:
- expiration
- validation
- invalid/expired handling
- no permanent secret embedded in the QR

Flow:
Sender -> Scan QR -> real connection -> transfer.

## 19. Connectivity Architecture

Primary transport/discovery:
Google Nearby Connections, using current official Android APIs.

Do not implement fake discovery or fake transport.

Optional local-network fallback can be isolated behind an interface using:
- NSD/mDNS discovery
- local TCP/HTTP-style streaming

The user must never configure IP addresses, ports or protocols.

Suggested abstraction:
TransportProvider
- NearbyTransportProvider
- LocalNetworkTransportProvider
- optional WifiDirectTransportProvider only if later required

## 20. Core Transfer Architecture

Recommended layers:

UI
-> ViewModel
-> TransferManager
-> ConnectionManager
-> TransportProvider
-> StorageManager

Supporting components:
- DeviceDiscovery
- TransferQueue
- TransferSession
- TransferItem
- TransferRepository
- IntegrityManager
- NotificationManager

The UI must never directly own sockets, discovery callbacks or file streams.

## 21. File Handling

Modern Android APIs:
- Photo Picker
- Storage Access Framework
- ContentResolver streams
- scoped storage compatible paths

Never load a large file fully into RAM.
Never base64 encode giant files.
Do file/network work off the main thread.

Use temporary/partial files for incomplete transfers, for example `.partial`, and finalize only after successful completion.

Handle:
- duplicate names
- missing source
- revoked URI permission
- changed source file
- zero-byte file
- Unicode names
- long names
- invalid names
- insufficient storage

## 22. Multiple Files

V1 should support multi-select and a real queue.

Need:
- per-file status
- overall progress
- completed count
- failed count
- retry
- cancel remaining

Optimize v1 for one sender -> one receiver. Do not add complex multi-receiver broadcasting unless explicitly requested later.

## 23. Large Files

Must support realistic large transfers.

Requirements:
- streaming
- buffered I/O
- bounded memory
- no whole-file ByteArray
- no UI-thread I/O

Test at least:
100 MB
500 MB
1 GB
5 GB+

## 24. Integrity and Reliability

Validate:
- expected size
- completion state
- truncation
- destination write success

Where appropriate, compare checksums/hashes.

Transfer states should include at least:
QUEUED, DISCOVERING, CONNECTING, AUTHENTICATING, WAITING_FOR_ACCEPT, ACCEPTED, TRANSFERRING, RETRYING, COMPLETED, FAILED, CANCELLED, CONNECTION_LOST, STORAGE_ERROR, PERMISSION_ERROR.

## 25. Background Transfer

Follow current Android background execution and foreground-service requirements.

Where needed, use an appropriate user-visible foreground service for long-running transfers.

Notification example:
Sending files
1.2 GB / 1.7 GB
72%
38 MB/s

Release the service and connectivity resources when finished/cancelled/failed.

## 26. Permissions

Request only permissions required by the actual implementation and current target SDK.

Potential permission areas depend on implementation:
- nearby/Wi-Fi device access
- Bluetooth-related access where required
- local-network access on Android versions/target SDKs that require it
- notifications where required
- foreground-service requirements
- media/file access only where actually needed

Rules:
- no permission dump on first launch
- request in context
- explain why
- offer recovery to Settings if denied

## 27. AdMob

Use the current official AdMob Android SDK.

V1:
- one bottom adaptive banner
- dedicated ad container
- clear visual separation from app controls
- no overlap with navigation/buttons
- no ad on top of the transfer controls
- hide banner for verified ad-free users

Development:
- use official AdMob test ad IDs
- never use live ads while debugging/testing

Do not interrupt the send/receive workflow with aggressive interstitials.

If an interstitial is ever added later, use only a genuine natural transition such as after a completed task and frequency-limit it.

## 28. Remove Ads / Pro

Menu entry:
Remove Ads

Purchase screen:
Go Ad-Free
One-time purchase
Purchase
Restore purchase

Entitlement must be real and persistent.
When verified:
- hide banner ads
- keep all core transfer features unchanged

Do not fake premium state.

## 29. Performance

Targets:
- smooth UI
- no ANRs
- bounded memory
- efficient thumbnails
- minimal unnecessary recomposition
- lazy lists
- correct lifecycle cleanup

Stop discovery/advertising when no longer needed.
Cancel jobs/coroutines on lifecycle end.
Release streams and connections.

## 30. Security

Never trust remote metadata.

Protect against:
- path traversal
- arbitrary destination writes
- malformed filenames
- invalid QR data
- expired sessions
- oversized declared transfers
- fake completion
- malformed metadata

Use the selected transport's real authentication/security facilities.

Never silently install APKs or bypass Android security.

## 31. Accessibility and Localization

Support:
- TalkBack labels
- sensible touch targets
- readable contrast
- scalable text
- information not conveyed only by color

Put user-facing text in Android resources.
Initial languages can be English and Hindi.

## 32. Required V1 Screens

1. Splash
2. Profile Setup
3. Home
4. Send - File Selection
5. Send - Selected Files Review
6. Device Discovery
7. Connection / Verification
8. Incoming Transfer Request
9. Transfer Progress
10. Transfer Complete
11. Receive Waiting
12. History
13. History Details
14. Settings
15. Profile Edit
16. QR Scanner
17. QR Display
18. Remove Ads / Purchase
19. Permission/Error states as overlays or recovery screens

Do not create extra feature screens without a real functional reason.

## 33. Development Order

Phase 1:
Project, Gradle, Compose, Material 3, navigation, themes.

Phase 2:
Splash, Profile, Home, Menu, Settings, Light/Dark.

Phase 3:
Real file picker and review screen.

Phase 4:
Real Nearby Connections discovery/connection/authentication.

Phase 5:
One real file transfer between two physical Android devices.

Phase 6:
Multi-file queue, progress, cancellation and completion.

Phase 7:
Receive flow, destination, conflict handling, error recovery.

Phase 8:
Background transfer and notifications.

Phase 9:
QR fallback.

Phase 10:
Room history.

Phase 11:
AdMob + real Remove Ads purchase flow.

Phase 12:
Security, accessibility, performance, Android-version compatibility and final polish.

## 34. Milestone Zero

Before creating the complete app, prove this exact real workflow:

Android Device A
-> real device discovery
-> real connection/authentication
-> select one real file
-> send
-> Android Device B receives the real file
-> verify the received file

Only after this works should the rest of the features be expanded.

## 35. Google AI Studio Master Instruction

Build this project as a production-oriented Android application in Kotlin using Jetpack Compose and Material 3.

The product is a SIMPLE, PREMIUM, QUICK-SHARE-STYLE nearby file transfer app.

Do not turn it into a feature-heavy utility suite.

STRICTLY DO NOT add demo videos, sample content, fake devices, fake history, fake transfer speeds, fake progress, simulated discovery, simulated transfers, timer-based completion, placeholder networking or buttons that only look functional.

The app must work on real Android devices.

Default visual direction:
LIGHT MODE first, with a fully polished DARK MODE.

First launch:
Splash -> Profile Setup -> Home.

Profile setup:
- original avatar selection
- device name
- local DataStore
- no login

Home:
- large Send
- large Receive
- smaller History
- compact top bar
- minimal side menu
- bottom AdMob banner in a dedicated separated area

Send flow:
Home -> Send -> real Android picker -> multi-select -> review -> real nearby discovery -> real connection/authentication -> receiver accepts -> real transfer -> completion.

Receive flow:
Home -> Receive -> real receiving mode -> incoming request -> Accept/Decline -> real transfer -> completion.

Use current official Google Nearby Connections APIs for the primary nearby transport/discovery mechanism.

Do not simulate device discovery or file transfer.

Use a TransportProvider abstraction so a local-network NSD/mDNS transport can be added later without rewriting UI or business logic.

For large files:
- stream files
- no whole-file ByteArray
- no base64 for large files
- no main-thread file/network I/O
- support multi-file queue

Transfer UI must show real bytes, real percentage, real speed and real remaining time estimate.

Do not hard-code progress or speed.

Use appropriate Android background/foreground-service behavior for long transfers and provide real notifications.

Use modern Photo Picker/Storage Access Framework and scoped-storage-safe file handling.

Use temporary files for incomplete transfers and finalize only after successful completion.

Implement QR as a real fallback with short-lived validated session data.

Use Room for real transfer history and DataStore for profile/settings.

AdMob:
- official current Android SDK
- one bottom adaptive banner
- dedicated container
- clear separation from buttons/navigation
- test ad IDs during development
- hide banner after verified ad-free purchase
- do not interrupt transfers with ads

Remove Ads:
- real Google Play Billing purchase
- real restore
- real entitlement handling

UI:
- original design
- no pixel-copy of Quick Share/InShare
- no copied logos/assets/avatars
- premium spacing
- modern typography
- subtle animation
- restrained gradients
- strong Light Mode
- equally polished Dark Mode

Do not add:
- web share dashboard
- social features
- cleaner/booster
- games
- app recommendations
- unnecessary media tools
- extra utilities
- demo/tutorial videos

Development rules:
1. Inspect the full project before changing architecture.
2. Keep the project buildable after every phase.
3. Fix compilation errors before adding more features.
4. Never leave core transfer methods as placeholders.
5. Never use fake data in the actual production workflow.
6. Keep I/O and network work off the main thread.
7. Clean up discovery, connections, streams, coroutines and services correctly.
8. Handle Android-version-specific permissions correctly.
9. Implement real user-readable error recovery.
10. Do not bypass Android security or permission restrictions.
11. Do not silently install APKs.
12. Test the core transfer on two physical Android devices before declaring it functional.

## 36. Final Definition of Done

The app is complete only when:
- real Android devices discover each other
- real connection/authentication works
- real files are selected
- real files transfer
- large files do not cause memory crashes
- multi-file transfer works
- progress is real
- cancel works
- receive works
- errors have recovery paths
- background transfer follows Android rules
- history is real
- QR fallback is real
- Light Mode is polished
- Dark Mode is polished
- AdMob banner works
- Remove Ads purchase state is real
- no demo content remains
- there are no critical crashes/ANRs in tested flows

## 37. Official Documentation To Check While Implementing

Always verify current Android behavior against official documentation, especially when target SDK or OS versions change:
- Google Quick Share / Android Help
- Google Nearby Connections Android
- Android Network Service Discovery (NSD)
- Android Wi-Fi permissions / Wi-Fi Direct
- Storage Access Framework
- Photo Picker
- Foreground services / background execution
- Material 3
- Google AdMob Android documentation

Do not use obsolete blog posts when current official documentation is available.
